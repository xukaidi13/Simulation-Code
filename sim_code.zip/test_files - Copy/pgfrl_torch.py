import torch
import torch.optim as optim
import torch.nn as nn
import gym
from copy import deepcopy


# Define the network architecture
class PolicyNetwork(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(PolicyNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, 64)
        self.fc2 = nn.Linear(64, action_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = nn.functional.softmax(self.fc2(x), dim=-1)
        return x


# Define the agent
class Agent:
    def __init__(self, state_dim, action_dim, lr=0.001, gamma=0.99):
        self.policy_net = PolicyNetwork(state_dim, action_dim)
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)
        self.gamma = gamma

    def get_action(self, state):
        with torch.no_grad():
            state = torch.FloatTensor(state)
            probs = self.policy_net(state)
            action = torch.distributions.Categorical(probs).sample().item()
        return action

    def update(self, experiences):
        states, actions, rewards, next_states, dones = experiences

        # Compute the discounted rewards-to-go
        returns = torch.zeros_like(rewards)
        R = 0
        for t in reversed(range(len(rewards))):
            R = rewards[t] + self.gamma * R * (1 - dones[t])
            returns[t] = R

        # Normalize the rewards
        returns = (returns - returns.mean()) / (returns.std() + 1e-6)

        # Compute the log probabilities of the actions taken
        logits = self.policy_net(states)
        log_probs = torch.distributions.Categorical(logits=logits).log_prob(actions)

        # Compute the loss and update the policy network
        loss = -(log_probs * returns).mean()
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# Define the federated learning function
def fed_agg(agents, num_clients):
    all_q_networks = [client_agent.q_network.state_dict() for client_agent in agents]
    avg_q_network = {}
    for key in all_q_networks[0].keys():
        avg_q_network[key] = sum([q_network[key] for q_network in all_q_networks]) / num_clients


