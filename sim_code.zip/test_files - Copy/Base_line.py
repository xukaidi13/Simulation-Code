# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 19:13:54 2021

@author: HP
"""
import numpy as np
from scipy.optimize import linprog
import matplotlib.pyplot as plt

from scipy import special
def Q_fun(x):
    return 0.5 - 0.5*special.erf(x/np.sqrt(2)) # Q(f) = 0.5 - 0.5 erf(f/sqrt(2))

# P_max: the maximun power of each BS (N)
def RNC_alg(R, h1, P_max,     M, N, L, Server, User, sigma, interf_fade ):
    h = np.abs(h1)**2
    Y = np.zeros([M, L])
    X = np.zeros([N, L])
    Phi = [[] for n in range(N)]
    Omega = np.zeros(M)
    for l in range(L):
        Pi_order = np.argsort(np.array([len(Phi[n]) for n in range(N)])/R )
        y = np.zeros(M)
        x = np.zeros(N)
        for n in range(N):
            k = Pi_order[n]
            for m in User[k]:                
                e = np.zeros(M)
                e[m] = 1
                Omega[m] = T_n(y + e, h, P_max, l, M, N, L, Server, User, sigma, interf_fade) - T_n(y, h, P_max, l, M, N, L, Server, User, sigma, interf_fade)
            m_star = np.argsort(Omega[User[k]])+User[k][0]
            m_count = -1
            while(Omega[m_star[m_count]]>0):                
                if sum(Y[m_star[m_count], :])==0:
                    x[k] = 1
                    y[m_star[m_count]] = 1
                    Phi[k].append(l)
                    break
                m_count-=1
                if m_count <= -len(User[k])-1:
                    break
        X[:, l] = x
        Y[:, l] = y
    sum_rate = Sum_rate(Y, h, P_max, M, N, L, Server, User, sigma, interf_fade)
    return Y, sum_rate


def Sum_rate(Y, h, P_max, M, N, L, Server, User, sigma, interf_fade):
    I = np.zeros(M)
    R_out = 0
    for l in range(L):
        for m in range(M):
            interf_w = 0
            for n in range(N):
                if n!=Server[m]:
                    interf_w += P_max[n]*h[m, n, l]*sum(Y[User[n], l])
            I[m] = np.log(1 + Y[m, l]*P_max[Server[m]]*h[m, Server[m], l]/(interf_w*interf_fade + sigma**2))
            R_out += I[m]
    return R_out


def T_n(y, h, P_max, l, M, N, L, Server, User, sigma, interf_fade):
    S = np.zeros(M)
    I = np.zeros(M)
    J = np.zeros(M)
    delta = np.zeros(M)
    T_out = 0
    for m in range(M):
        interf_w = 0
        interf_o = 0
        max_interf = 0
        index_int = 0
        for n in range(N):
            if n!=Server[m]:
                interf_w += P_max[n]*h[m, n, l]#*sum(y[User[n]])
                if P_max[n]*h[m, n, l] > max_interf:
                    max_interf = P_max[n]*h[m, n, l]
                    index_int = n
        interf_o = interf_w - max_interf
        J[m] = index_int
        S[m] = np.log(1 + y[m]*P_max[Server[m]]*h[m, Server[m], l]/(interf_o*interf_fade + sigma**2))
        I[m] = np.log(1 + y[m]*P_max[Server[m]]*h[m, Server[m], l]/(interf_w*interf_fade+ sigma**2))
        delta[m] = S[m] - I[m]
        T_out += y[m]*(S[m] - delta[m]*sum(y[User[int(J[m])]]))
    return T_out


class FP:
    def __init__(self, M_n, L, N, M, User):
        self.temp = np.zeros([M, L])
        
        self.power_rece = np.zeros([M, N, L])
        coef_left_temp1 = np.zeros([M, M, L])
        coef_left_temp2 = np.zeros([L*N, M, L])
        coef_left1 = np.zeros([M, M*L])
        coef_left2 = np.zeros([L*N, M*L])
        for m in range(M):
            coef_left_temp1[m, m, :] = np.ones(L)
            coef_left1[m, :] = coef_left_temp1[m, :, :].reshape([M*L])
        for n in range(N):
            for l in range(L):
                coef_left_temp2[l+n*L, User[n], l] = np.ones(M_n)
                coef_left2[l+n*L, :] = coef_left_temp2[l+n*L, :, :].reshape([M*L])
        self.coef_left = np.vstack((coef_left1, coef_left2))
        self.coef_right = np.ones(M+L*N)         
        self.bnd = [(0,1)]*(M*L)
    
    def FP_alg(self, h, P_max, M, N, L, Server, User, sigma,A_C):
        P = np.ones([N, L])*P_max[0]
        for m in range(M):
            for n in range(N):
                for l in range(L):
                    self.power_rece[m, n, l] = P[n, l]*np.abs(h[m, n, l])**2
        gammas = self.update_gammas(h,  P, M, N, L, Server, User, sigma)
        y = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                y[m, l] = ((1+gammas[m, l])*P[Server[m],l]*np.abs(h[m, Server[m], l])**2)**0.5 \
                    /(sigma**2 + self.power_rece[m, :, l].sum())
        alphas, obj_alpha = self.update_alphas(h, y, gammas,  P, M, N, L, Server, User, sigma)
        alphas = np.ones([M, L])
        
        obj_list=[]
        count = 0
        
        while 1:            
            y = self.update_y(h, alphas, gammas,  P, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            # alphas, obj_alpha = self.update_alphas(h, y, gammas,  P, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            gammas = self.update_gammas(h,  P, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            P = self.update_p(h, alphas, gammas, y, P_max, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            
            obj_list.append(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            
            if (count >1)&(obj_list[count]-obj_list[count-1]<10**-5):
                break
            count+=1        
        # sum_rate = self.performance(h, P, M, L, alphas, Server, sigma)
        # actions = self.convert_alphas2actions(alphas, P, N, L, P_max, User,A_C)
        # return actions.astype(int)
        return P#actions, sum_rate
    
    def update_p(self, h, alphas, gammas, y, P_max, M, N, L, Server, User, sigma):
        temp_frac = np.zeros([N,L])
        temp_no   = np.zeros([N,L])
        P = np.zeros([N, L])
        for n in range(N):
            for m in range(M):
                for l in range(L):
                    temp_frac[n,l] += alphas[m, l]*y[m,l]**2*np.abs(h[m,n,l])**2
        for n in range(N):
            for m in User[n]:
                for l in range(L):
                    temp_no[n, l] += (alphas[m, l]*y[m,l])**2*(1+gammas[m,l])*np.abs(h[m, n, l])**2
        for n in range(N):
            for l in range(L):
                P[n,l] = min([temp_no[n,l]/temp_frac[n,l]**2, P_max[n]])
        # update power_rece
        for m in range(M):
            for n in range(N):
                for l in range(L):
                    self.power_rece[m, n, l] = P[n, l]*np.abs(h[m, n, l])**2
        return P
    
    def update_y(self, h, alphas, gammas,  P, M, N, L, Server, User, sigma):
        y = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                y[m, l] = ((1+gammas[m, l])*P[Server[m],l]*np.abs(h[m, Server[m], l])**2)**0.5 \
                    /(sigma**2 + self.power_rece[m, :, l].sum())
        return y
    
    def update_gammas(self, h,  P, M, N, L, Server, User, sigma):
        gammas = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                gammas[m, l] = self.power_rece[m, Server[m], l]/(sigma**2+self.power_rece[m, :, l].sum() - self.power_rece[m, Server[m], l])
        return gammas
    
    def update_alphas(self, h, y, gammas,  P, M, N, L, Server, User, sigma):
        coef = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                coef[m,l] = np.log(1+gammas[m,l]) - gammas[m,l] + 2*y[m,l]*np.abs(h[m, Server[m],l])*((1+gammas[m,l])*P[Server[m], l])**0.5 \
                    - y[m,l]**2*(sigma**2 + self.power_rece[m,:,l].sum())        
        coef_obj = -1*coef.reshape([M*L])
        opt = linprog(c=coef_obj, A_ub=self.coef_left, b_ub=self.coef_right,
              bounds=self.bnd, method="simplex")
        obj = -1*opt.fun
        x = opt.x
        alphas = x.reshape([M, L])
        return alphas, obj
        
    def convert_alphas2actions(self, alphas, P, N, L, P_max, User, A_C):
        actions = np.zeros([N, L, 2])
        for n in range(N):
            for l in range(L):
                actions[n,l,1] = P[n,l]//(P_max[0]/A_C+0.0001)*P_max[0]
        for n in range(N):
            for l in range(L):
                actions[n,l,0] = alphas[User[n],l].argmax()+User[n][0]
        return actions
    
    def performance(self, h, P, M, L, alphas, Server,sigma):
        out = 0
        for m in range(M):
            for l in range(L):
                out += alphas[m,l]*np.log(1+ P[Server[m], l]*np.abs(h[m,Server[m],l])**2/(sigma**2 + (np.abs(h[m,:,l])**2*P[:, l]).sum() -  P[Server[m], l]*np.abs(h[m,Server[m],l])**2))
        return out       
        
    def FP_obj(self, h, alphas, gammas, y, P, M, N, L, Server, User, sigma):
        for m in range(M):
            for l in range(L):
                # self.temp[m,l] = np.log(1+gammas[m, l]) - gammas[m, l] + 2*y[m, l]*((1+gammas[m, l])*P[Server[m],l]*np.abs(h[m, Server[m], l])**2)**0.5\
                #     - y[m,l]**2*(sigma**2+self.power_rece[m, :, l].sum())
                self.temp[m,l] = np.log(1+gammas[m, l]) - gammas[m, l] + ((1+gammas[m, l])*self.power_rece[m, Server[m], l])/(sigma**2+self.power_rece[m, :, l].sum())
        final_obj = (self.temp*alphas).sum()
        return final_obj
            
    
            
class WMMSE:
    def __init__(self, ):
        1
        
    def WMMSE_alg(self, h, P, P_max, N, sigma, test_point = 100000000):
        # P = np.ones([N])*P_max**0.5
        # U = self.update_u( h, P, N, sigma)
        # W = self.update_w( U, h, P, N)
        
        obj_list = []
        count = 0
        # obj1 = 100
        while 1:
            U = self.update_u( h, P, N, sigma)
            # obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            W = self.update_w( U, h, P, N) 
            # if np.log(W).sum()>test_point:
            #     break
            # obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            # print(obj)
            P = self.update_p( h, P_max, W, U, N, sigma)
            obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            # print(obj)
            obj_list.append(obj)
            if (obj_list[count] - obj_list[count-1] > -10**-3)&(count>1500):
                break
            count +=1
            if count>1500:
                break
            
        return P
    
    def WMMSE_alg1(self, h, P, P_max, N, sigma, weights):
        # P = np.ones([N])*P_max**0.5
        U = self.update_u( h, P, N, sigma)
        W = self.update_w( U, h, P, N)
        
        obj_list = []
        count = 0
        # obj1 = 100
        while 1:
            U = self.update_u( h, P, N, sigma)
            # obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            W = self.update_w( U, h, P, N) 
            # obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            # print(obj)
            P = self.update_p1( h, P_max, W, U, N, sigma, weights)
            obj = self.WMMSE_obj1(h, N, P, W, U, sigma, weights)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            # print(obj)
            obj_list.append(obj)
            if (obj_list[count] - obj_list[count-1] > -10**-3)&(count>1):
                break
            count +=1
            # if count>5:
            #     break
            
        return P
    
    def update_p1(self, h, P_max, W, U, N, sigma, weights):
        P = np.zeros(N)
        for k in range(N):
            P[k] = h[k, k]*U[k]*W[k]*weights[k]/((h[:, k]**2*U**2*W*weights).sum())
            P[k] = min(P[k], P_max**0.5)
        return P
        
    def update_p(self, h, P_max, W, U, N, sigma):
        P = np.zeros(N)
        for k in range(N):
            P[k] = h[k, k]*U[k]*W[k]/((h[:, k]**2*U**2*W).sum())
            P[k] = min(P[k], P_max**0.5)
        return P
    def update_u(self, h, P, N, sigma):
        U = np.zeros(N)
        for k in range(N):
            U[k] = h[k,k]*P[k]/((h[k, :]**2*P**2).sum()+sigma**2)
        return U
    def update_w(self, U, h, P, N):
        W = np.zeros(N)
        for k in range(N):
            W[k] = 1/(1 - U[k]*h[k, k]*P[k])
            if np.isnan(W.sum()):
                aaa=1
        return W
    def WMMSE_obj(self, h, N, P, W, U, sigma):
        e = np.zeros([N])
        for k in range(N):
            e[k] = np.abs(U[k]*h[k,k]*P[k]-1)**2 \
                + (np.abs(U[k]*h[k, :]*P)**2).sum() \
                    - np.abs(U[k]*h[k, k]*P[k])**2 + sigma**2*np.abs(U[k])**2
        obj = (e*W).sum() - np.log(W).sum()
        return obj
    def WMMSE_obj1(self, h, N, P, W, U, sigma, weights):
        e = np.zeros([N])
        for k in range(N):
            e[k] = np.abs(U[k]*h[k,k]*P[k]-1)**2 \
                + (np.abs(U[k]*h[k, :]*P)**2).sum() \
                    - np.abs(U[k]*h[k, k]*P[k])**2 + sigma**2*np.abs(U[k])**2
        obj = (weights*e*W).sum() - (weights*np.log(W)).sum()
        return obj
    

class MSUPC_CP:
    def __init__(self,):
        self.delta_c = 0.01
        self.b = 1
        
    def Network_part(self, h_all, M, p_max, sigma):
        c = 0
        U_all = np.zeros(M)
        p_star = np.zeros(M)
        sum_rate = 0
        while 1:
            U_all_last = U_all.copy()
            p_star_last = p_star.copy()
            sum_rate_last = sum_rate
            p_star, U_all = self.User_all(h_all, M, c, p_max, sigma)
            sum_rate = self.sum_rate(p_star, h_all, sigma, M)
            c += self.delta_c
            
            if (sum_rate_last>sum_rate):
                break
        return p_star
    
    def sum_rate(self, p_all, h_all, sigma, M):
        received_power = (np.abs(h_all)**2).dot((p_all**2).reshape([M, 1])).squeeze()
        desired_power = np.abs(h_all[range(M), range(M)])**2*(p_all**2)
        interf_power = received_power - desired_power
        rates = np.log(1+received_power/(interf_power+sigma**2))
        return rates.sum()
    
    def User_all(self, h_all, M, c, p_max, sigma):
        p_all = np.random.rand(M)*p_max
        P_list = np.linspace(0, p_max**2, 1000)
        U_all = np.zeros(M)
        while 1:
            p_all_last = p_all.copy()
            received_power = (np.abs(h_all)**2).dot((p_all**2).reshape([M, 1])).squeeze()
            desired_power = np.abs(h_all[range(M), range(M)])**2*(p_all**2)
            interf_power = received_power - desired_power
            for m in range(M):
                out_U = self.User_i(h_all[m, m], c, interf_power[m], p_max, sigma)
                p_all[m] = np.sqrt(P_list[np.argmax(out_U)])
                U_all[m] = np.max(out_U)
            if np.abs(p_all-p_all_last).sum()<30:
                break
        return p_all, U_all
            
    def User_i(self, h, c, interf, p_max, sigma):
        P_test = np.linspace(0, p_max**2, 1000)+1e-5
        gamma = P_test*h**2/(interf+sigma**2)
        f = (1-Q_fun(np.sqrt(gamma*2)))**100 - (1-Q_fun(0))**100
        out = np.log(self.b*f+1)/P_test - c*(np.exp(P_test/1000)-1)
        return out
        
    