import sys

a = sys.argv[1]
print(a)