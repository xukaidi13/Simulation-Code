import torch
import numpy as np
import torch.optim as optim
import torch.nn as nn
import random


# HNL1 = 256
# HNL2 = 128
HNL3 = 64
class QNet(nn.Module):
    def __init__(self, HNIN, HNOUT, index):
        super(QNet, self).__init__()
        self.fc4 = nn.Linear(64, HNOUT)
        self.fc4_mean = nn.Linear(64, 1)
        self.LKRL = nn.LeakyReLU(0.1)
        if index == 0:
            self.actor = nn.Sequential(
                nn.Linear(HNIN, 128),
                nn.LeakyReLU(0.1),
                nn.Linear(128, 128),
                nn.LeakyReLU(0.1),
                nn.Linear(128, 64)
            )
        elif index in [1, 2, 3, 4]:
            self.actor = nn.Sequential(
                nn.Linear(HNIN, 128),
                nn.LeakyReLU(0.1),
                nn.Linear(128, 64)
            )
        elif index in [5, 6, 7, 8]:
            self.actor = nn.Sequential(
                nn.Linear(HNIN, 64),
                nn.LeakyReLU(0.1),
                nn.Linear(64, 64)
            )

    def forward(self, s):
        # temp = self.LKRL(self.cop_fc2(self.LKRL(
        #     self.cop_fc1(s))))
        temp1 = self.actor(s)
        out = self.fc4(temp1) - torch.mean(self.fc4(temp1), 1, keepdim=True) + self.fc4_mean(temp1)
        # self.LKRL(self.fc1(s)))))))
        return out


class PNet(nn.Module):
    def __init__(self, HNIN, HNOUT, index):
        super(PNet, self).__init__()
        self.fc4 = nn.Linear(HNL3, HNOUT)
        self.LKRL = nn.LeakyReLU(0.1)
        if index == 0:
            self.actor = nn.Sequential(
                nn.Linear(HNIN, 128),
                nn.LeakyReLU(0.1),
                nn.Linear(128, 128),
                nn.LeakyReLU(0.1),
                nn.Linear(128, 64)
            )
        elif index in [1, 2, 3, 4]:
            self.actor = nn.Sequential(
                nn.Linear(HNIN, 128),
                nn.LeakyReLU(0.1),
                nn.Linear(128, 64)
            )
        elif index in [5, 6, 7, 8]:
            self.actor = nn.Sequential(
                nn.Linear(HNIN, 64),
                nn.LeakyReLU(0.1),
                nn.Linear(64, 64)
            )

    def forward(self, s):
        # temp = self.LKRL(self.cop_fc2(self.LKRL(
        #     self.cop_fc1(s))))
        temp1 = self.actor(s)
        out = nn.functional.softmax(self.fc4(temp1), dim=-1)
        # self.LKRL(self.fc1(s)))))))
        return out


class NfspAgent:
    def __init__(self, A_C, state_dim, LR, HNIN, HNOUT, index):
        self.eval_q_net = QNet(HNIN, HNOUT, index).cuda()
        self.p_net = PNet(HNIN, HNOUT, index).cuda()
        self.optimizer_q = torch.optim.Adam(self.eval_q_net.parameters(), lr=LR)
        self.optimizer_p = torch.optim.Adam(self.p_net.parameters(), lr=LR)
        self.eta = 0.5
        self.memory_capacity = 3600
        self.memory_sl_capacity = 14400
        self.memory_counter = 0
        self.memory_sl_counter = 0
        self.memory = []
        self.memory_sl = []
        self.a_c = A_C
        self.batch_size = 128
        self.state_dim = state_dim
        self.reward_dim = 1
        self.gamma = 0

    def store_transition(self, s, a, r, s_, is_sl):
        if self.memory_counter < self.memory_capacity:
            self.memory.append((s, a, r, s_))
        else:
            self.memory[self.memory_counter % self.memory_capacity] = (s, a, r, s_)
        if is_sl:
            if self.memory_sl_counter < self.memory_sl_capacity:
                self.memory_sl.append((s, a))
            else:
                self.memory_sl[self.memory_sl_counter % self.memory_sl_capacity] = (s, a)
            self.memory_sl_counter += 1
        self.memory_counter += 1

    def choose_action(self, s, epsilon, is_test=0):
        s = torch.FloatTensor(s).view([1, -1]).cuda()
        if random.uniform(0, 1) < self.eta:
            is_sl = 1
            if random.uniform(0, 1) < epsilon:
                action = self.eval_q_net(s).squeeze().argmax().cpu().numpy()
            else:
                action = np.random.randint(0, self.a_c)
        else:
            is_sl = 0
            probs = self.p_net(s).squeeze()
            action = torch.distributions.Categorical(probs=probs).sample().item()
        if is_test:
            action = self.eval_q_net(s).squeeze().argmax().cpu().numpy()
        return action, is_sl

    def learn(self,):
        memory_temp = (random.sample(self.memory_sl, self.batch_size))
        b_s_sl = torch.FloatTensor(np.array([d[0] for d in memory_temp])).view([-1, self.state_dim]).cuda()
        b_a_sl = torch.LongTensor(np.array([d[1] for d in memory_temp])).view([-1, 1]).cuda()
        out = self.p_net(b_s_sl)
        probs = torch.gather(out, 1, b_a_sl)
        self.optimizer_p.zero_grad()
        loss_sl = -torch.log(probs).mean()
        loss_sl.backward()
        self.optimizer_p.step()
        memory_temp = (random.sample(self.memory, self.batch_size))
        b_s = torch.FloatTensor(np.array([d[0] for d in memory_temp])).view([-1, self.state_dim]).cuda()
        b_a = torch.LongTensor(np.array([d[1] for d in memory_temp])).view([-1, 1]).cuda()
        b_r = torch.FloatTensor(np.array([d[2] for d in memory_temp])).view([-1, self.reward_dim]).cuda()
        b_s_ = torch.FloatTensor(np.array([d[3] for d in memory_temp])).view([-1, self.state_dim]).cuda()
        temp_q = self.eval_q_net(b_s)
        q_eval = torch.gather(temp_q, 1, b_a).squeeze()
        q_target = b_r.squeeze()
        self.optimizer_q.zero_grad()
        loss_rl = ((q_eval - q_target)**2).mean()
        loss_rl.backward()
        self.optimizer_q.step()
