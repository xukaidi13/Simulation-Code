 # -*- coding: utf-8 -*-
"""
Created on Fri Oct  1 10:45:45 2021

@author: xukai
"""
import numpy as np

def rate_check(s_g_all, actions, M, N):
    interf = np.zeros([M])
    Rate_all = np.zeros([M])
    for n in range(N):
        for j in range(N):
            if j!=n:
                interf[n] += np.abs(s_g_all[n, j])**2*actions[j]
        Rate_all[n] = np.log(1 + ( np.abs(s_g_all[n, n])**2*actions[n] )/(interf[n] + 1 ))                
    # a = np.sum(np.log(Rate_all.sum(1)+10**-3))
    a = np.sum(Rate_all)
    return a, Rate_all