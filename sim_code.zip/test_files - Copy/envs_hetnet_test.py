# -*- coding: utf-8 -*-
"""
Created on Sun Oct 23 16:46:07 2022

@author: xukai
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Aug 21 18:49:07 2021

@author: Kaidi Xu
"""

import numpy as np
import random
from scipy import special
import math

# self.d is a matrix indicating different distance between nodes
# Rho is a 2-D array, Rho_{m,l} denote that user m receives signal from BS in subchannel l
class Envir:
    def __init__(self, M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis, P_max_all):
        self.M = M
        self.M_n = M_n
        self.M_reach = M_reach
        self.N = N
        self.N_reach = N_reach
        self.A_C = A_C
        self.N_local_inf = N_local_inf
        self.N_local_inf_all = N_local_inf_all
        self.N_R_inf = N_R_inf
        self.N_out_R = N_out_R
        self.N_ext_inf = N_ext_inf
        self.N_out_T = N_out_T        
        self.reward_nei = 4
        
        self.Max_related_in_T = Max_related_in_T
        self.Max_related_in_R = Max_related_in_R
        # xy_Tx, xy_Rx = self.generate_positions_hetnet()
        # self.d = self.generate_dist(xy_Tx, xy_Rx)
        # self.M_index, self.N_index, self.reward_nei_index, self.M_interf = self.generate_indices(self.d)
        self.Server = Server
        self.User = User
        self.sigma = sigma
        self.P_all = P_all
        self.P_code=[]
        for n in range(N):
            self.P_code.append(np.linspace(0, P_max_all[n], A_C))
        self.P_code = np.array(self.P_code)
        self.P_max_all = P_max_all
        self.last_actions = np.zeros([self.N]).astype(int)
        self.gamma = 1

        
        self.sigma = 10**(-11.4+11.4) # self.sigma is measured in dbm, so P sould be measured in dbm too
        self.channel_num = 100
        self.path_loss_con = 120.9-114 
        self.shadow = 10**(np.random.normal(0,8, [M, N])/20)
        # self.shadow = np.random.lognormal(sigma = 4, size = [self.M, self.N])
        self.path_loss_coe = 37.6
        self.fd = 10
        self.T = 0.02
        # self.h_all = np.zeros([self.M,self.N]).astype(complex) # Small scale channel gain
         # random.seed(3)
        # self.h_all = np.random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N*2)).view(np.complex128)
        # self.g_all = np.zeros([self.M,self.N]) # Channel gain
        # self.rho = 0
        
        
        # self.alpha = self.Channel_gain_between_ik(self.d)
        # self.alpha_no_shadow = self.alpha.copy()
        # self.alpha*= self.shadow
        # # self.User_association()
        # self.Channel_eval()
        # self.last_g_all = self.g_all.copy()
        
    def reset(self):
        SINR = np.zeros([self.M])
        Interf = np.zeros([self.M])
        Rate_Rx = np.zeros([self.M,1])
        return Rate_Rx, SINR, Interf, np.abs(self.g_all)

    def load_channels(self, epi_ind):
        path = './test_channels/'
        self.g_all0 = np.load(path + str(epi_ind) + 'g_all4f.npy')
        self.d_all0 = np.load(path + str(epi_ind) + 'd_all4f.npy')
        self.M_interf_all0 = np.load(path + str(epi_ind) + 'M_interf_all4f.npy')
        self.M_index_all0 = np.load(path + str(epi_ind) + 'M_index_all4f.npy')
        self.N_index_all0 = np.load(path + str(epi_ind) + 'N_index_all4f.npy')
        self.reward_nei_index_all0 = np.load(path + str(epi_ind) + 'reward_nei_index_all4f.npy')
        self.test_channel_count = 0
        self.g_all = self.g_all0[self.test_channel_count]
        self.d = self.d_all0[self.test_channel_count]
        self.M_interf = self.M_interf_all0[self.test_channel_count]
        self.M_index = self.M_index_all0[self.test_channel_count]
        self.N_index = self.N_index_all0[self.test_channel_count]
        self.reward_nei_index = self.reward_nei_index_all0[self.test_channel_count]

    def transition(self, actions, is_ddpg=False):
        if is_ddpg:
            power_all = actions * self.P_max_all
        else:
            power_all = np.take_along_axis(self.P_code, actions.reshape([self.N, 1]), axis=1)
        sinr_all, interf_all = self.get_sinr(power_all.squeeze())
        rate_all = np.log(1 + sinr_all)
        # rate_all = np.minimum(rate_all, np.log(1000))
        self.test_channel_count += 1
        if self.test_channel_count >= 4000:
            print(self.test_channel_count)
            self.test_channel_count -= 1
        self.g_all = self.g_all0[self.test_channel_count]
        self.d = self.d_all0[self.test_channel_count]
        self.M_interf = self.M_interf_all0[self.test_channel_count]
        self.M_index = self.M_index_all0[self.test_channel_count]
        self.N_index = self.N_index_all0[self.test_channel_count]
        self.reward_nei_index = self.reward_nei_index_all0[self.test_channel_count]
        # if is_end
        return rate_all, sinr_all, interf_all, np.abs(self.g_all)

    def get_sinr(self, power):
        interf = np.zeros(self.M)
        all_power = np.array((np.abs(self.g_all)**2).dot(np.mat(power.reshape([self.N, 1])))).squeeze()
        desired_sig = np.diag(np.abs(self.g_all)**2)*power
        interf = all_power - desired_sig
        sinr_all = desired_sig/(interf + self.sigma**2)
        return sinr_all, interf   
    
    def Channel_eval(self):        
        self.rho = special.jv(0, 2*np.pi*self.fd*self.T)
        e =  np.random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N*2)).view(np.complex128)
        for m in range(self.M):
            for n in range(self.N):
                e[m,n] = (random.gauss(0,1) + 1j*random.gauss(0,1))*np.sqrt(2)/2
        self.h_all = self.rho*self.h_all + ((1-self.rho**2)**0.5)*e
        self.g_all = self.h_all*self.alpha
                
    def Channel_gain_between_ik(self, d):
        alpha_o = np.zeros([self.M,self.N])
        alpha_o = 10**(-1*(self.path_loss_con + self.path_loss_coe*np.log10(d))/20)
        for n in range(self.N):
            for m in range(self.M):
                alpha_o[m,n] = 10**(-1*(self.path_loss_con + self.path_loss_coe*math.log10(d[m, n]))/20)
        
        return alpha_o
    
    
            
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 24 19:13:54 2021

@author: HP
"""

# P_max: the maximun power of each BS (N)
def RNC_alg(R, h1, P_max, M, N, L, Server, User, sigma, interf_fade ):
    h = np.abs(h1)**2
    Y = np.zeros([M, L])
    X = np.zeros([N, L])
    Phi = [[] for n in range(N)]
    Omega = np.zeros(M)
    for l in range(L):
        Pi_order = np.argsort(np.array([len(Phi[n]) for n in range(N)])/R )
        y = np.zeros(M)
        x = np.zeros(N)
        for n in range(N):
            k = Pi_order[n]
            for m in User[k]:                
                e = np.zeros(M)
                e[m] = 1
                Omega[m] = T_n(y + e, h, P_max, l, M, N, L, Server, User, sigma, interf_fade) - T_n(y, h, P_max, l, M, N, L, Server, User, sigma, interf_fade)
            m_star = np.argsort(Omega[User[k]])+User[k][0]
            m_count = -1
            while(Omega[m_star[m_count]]>0):                
                if sum(Y[m_star[m_count], :])==0:
                    x[k] = 1
                    y[m_star[m_count]] = 1
                    Phi[k].append(l)
                    break
                m_count-=1
                if m_count <= -len(User[k])-1:
                    break
        X[:, l] = x
        Y[:, l] = y     
    sum_rate = Sum_rate(Y, h, P_max, M, N, L, Server, User, sigma, interf_fade)
    return Y, sum_rate


def Sum_rate(Y, h, P_max, M, N, Server, User, sigma, interf_fade):
    I = np.zeros(M)
    R_out = 0
    for m in range(M):
        interf_w = 0
        for n in range(N):
            if n!=Server[m]:
                interf_w += P_max[n]*h[m, n]*sum(Y[User[n]])
        I[m] = np.log(1 + Y[m]*P_max[Server[m]]*h[m, Server[m]]/(interf_w*interf_fade + sigma**2))
        R_out += I[m]
    return R_out


def T_n(y, h, P_max, l, M, N, L, Server, User, sigma, interf_fade):
    S = np.zeros(M)
    I = np.zeros(M)
    J = np.zeros(M)
    delta = np.zeros(M)
    T_out = 0
    for m in range(M):
        interf_w = 0
        interf_o = 0
        max_interf = 0
        index_int = 0
        for n in range(N):
            if n!=Server[m]:
                interf_w += P_max[n]*h[m, n, l]#*sum(y[User[n]])
                if P_max[n]*h[m, n, l] > max_interf:
                    max_interf = P_max[n]*h[m, n, l]
                    index_int = n
        interf_o = interf_w - max_interf
        J[m] = index_int
        S[m] = np.log(1 + y[m]*P_max[Server[m]]*h[m, Server[m], l]/(interf_o*interf_fade + sigma**2))
        I[m] = np.log(1 + y[m]*P_max[Server[m]]*h[m, Server[m], l]/(interf_w*interf_fade+ sigma**2))
        delta[m] = S[m] - I[m]
        T_out += y[m]*(S[m] - delta[m]*sum(y[User[int(J[m])]]))
    return T_out


class FP:
    def __init__(self, M_n, L, N, M, User):
        self.temp = np.zeros([M, L])
        
        self.power_rece = np.zeros([M, N, L])
        coef_left_temp1 = np.zeros([M, M, L])
        coef_left_temp2 = np.zeros([L*N, M, L])
        coef_left1 = np.zeros([M, M*L])
        coef_left2 = np.zeros([L*N, M*L])
        for m in range(M):
            coef_left_temp1[m, m, :] = np.ones(L)
            coef_left1[m, :] = coef_left_temp1[m, :, :].reshape([M*L])
        for n in range(N):
            for l in range(L):
                coef_left_temp2[l+n*L, User[n], l] = np.ones(M_n)
                coef_left2[l+n*L, :] = coef_left_temp2[l+n*L, :, :].reshape([M*L])
        self.coef_left = np.vstack((coef_left1, coef_left2))
        self.coef_right = np.ones(M+L*N)         
        self.bnd = [(0,1)]*(M*L)
    
    def FP_alg(self, h, P_max, M, N, L, Server, User, sigma,A_C):
        P = np.ones([N, L])*P_max[0]
        for m in range(M):
            for n in range(N):
                for l in range(L):
                    self.power_rece[m, n, l] = P[n, l]*np.abs(h[m, n, l])**2
        gammas = self.update_gammas(h,  P, M, N, L, Server, User, sigma)
        y = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                y[m, l] = ((1+gammas[m, l])*P[Server[m],l]*np.abs(h[m, Server[m], l])**2)**0.5 \
                    /(sigma**2 + self.power_rece[m, :, l].sum())
        alphas, obj_alpha = self.update_alphas(h, y, gammas,  P, M, N, L, Server, User, sigma)
        alphas = np.ones([M, L])
        
        obj_list=[]
        count = 0
        
        while 1:            
            y = self.update_y(h, alphas, gammas,  P, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            # alphas, obj_alpha = self.update_alphas(h, y, gammas,  P, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            gammas = self.update_gammas(h,  P, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            P = self.update_p(h, alphas, gammas, y, P_max, M, N, L, Server, User, sigma)
            # print(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            
            obj_list.append(self.FP_obj(h, alphas, gammas, y, P, M, N, L, Server, User, sigma))
            
            if (count >1)&(obj_list[count]-obj_list[count-1]<10**-5):
                break
            count+=1        
        # sum_rate = self.performance(h, P, M, L, alphas, Server, sigma)
        # actions = self.convert_alphas2actions(alphas, P, N, L, P_max, User,A_C)
        # return actions.astype(int)
        return P#actions, sum_rate
    
    def update_p(self, h, alphas, gammas, y, P_max, M, N, L, Server, User, sigma):
        temp_frac = np.zeros([N,L])
        temp_no   = np.zeros([N,L])
        P = np.zeros([N, L])
        for n in range(N):
            for m in range(M):
                for l in range(L):
                    temp_frac[n,l] += alphas[m, l]*y[m,l]**2*np.abs(h[m,n,l])**2
        for n in range(N):
            for m in User[n]:
                for l in range(L):
                    temp_no[n, l] += (alphas[m, l]*y[m,l])**2*(1+gammas[m,l])*np.abs(h[m, n, l])**2
        for n in range(N):
            for l in range(L):
                P[n,l] = min([temp_no[n,l]/temp_frac[n,l]**2, P_max[n]])
        # update power_rece
        for m in range(M):
            for n in range(N):
                for l in range(L):
                    self.power_rece[m, n, l] = P[n, l]*np.abs(h[m, n, l])**2
        return P
    
    def update_y(self, h, alphas, gammas,  P, M, N, L, Server, User, sigma):
        y = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                y[m, l] = ((1+gammas[m, l])*P[Server[m],l]*np.abs(h[m, Server[m], l])**2)**0.5 \
                    /(sigma**2 + self.power_rece[m, :, l].sum())
        return y
    
    def update_gammas(self, h,  P, M, N, L, Server, User, sigma):
        gammas = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                gammas[m, l] = self.power_rece[m, Server[m], l]/(sigma**2+self.power_rece[m, :, l].sum() - self.power_rece[m, Server[m], l])
        return gammas
    
    def update_alphas(self, h, y, gammas,  P, M, N, L, Server, User, sigma):
        coef = np.zeros([M, L])
        for m in range(M):
            for l in range(L):
                coef[m,l] = np.log(1+gammas[m,l]) - gammas[m,l] + 2*y[m,l]*np.abs(h[m, Server[m],l])*((1+gammas[m,l])*P[Server[m], l])**0.5 \
                    - y[m,l]**2*(sigma**2 + self.power_rece[m,:,l].sum())        
        coef_obj = -1*coef.reshape([M*L])
        opt = linprog(c=coef_obj, A_ub=self.coef_left, b_ub=self.coef_right,
              bounds=self.bnd, method="simplex")
        obj = -1*opt.fun
        x = opt.x
        alphas = x.reshape([M, L])
        return alphas, obj
        
    def convert_alphas2actions(self, alphas, P, N, L, P_max, User, A_C):
        actions = np.zeros([N, L, 2])
        for n in range(N):
            for l in range(L):
                actions[n,l,1] = P[n,l]//(P_max[0]/A_C+0.0001)*P_max[0]
        for n in range(N):
            for l in range(L):
                actions[n,l,0] = alphas[User[n],l].argmax()+User[n][0]
        return actions
    
    def performance(self, h, P, M, L, alphas, Server,sigma):
        out = 0
        for m in range(M):
            for l in range(L):
                out += alphas[m,l]*np.log(1+ P[Server[m], l]*np.abs(h[m,Server[m],l])**2/(sigma**2 + (np.abs(h[m,:,l])**2*P[:, l]).sum() -  P[Server[m], l]*np.abs(h[m,Server[m],l])**2))
        return out       
        
    def FP_obj(self, h, alphas, gammas, y, P, M, N, L, Server, User, sigma):
        for m in range(M):
            for l in range(L):
                # self.temp[m,l] = np.log(1+gammas[m, l]) - gammas[m, l] + 2*y[m, l]*((1+gammas[m, l])*P[Server[m],l]*np.abs(h[m, Server[m], l])**2)**0.5\
                #     - y[m,l]**2*(sigma**2+self.power_rece[m, :, l].sum())
                self.temp[m,l] = np.log(1+gammas[m, l]) - gammas[m, l] + ((1+gammas[m, l])*self.power_rece[m, Server[m], l])/(sigma**2+self.power_rece[m, :, l].sum())
        final_obj = (self.temp*alphas).sum()
        return final_obj
            
    
            
class WMMSE:
    def __init__(self, ):
        1
        
    def WMMSE_alg(self, h, P, P_max, N, sigma):
        # P = np.ones([N])*P_max**0.5
        U = self.update_u( h, P, N, sigma)
        W = self.update_w( U, h, P, N)
        
        obj_list = []
        count = 0
        # obj1 = 100
        while count<400:
            U = self.update_u( h, P, N, sigma)
            # obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            W = self.update_w( U, h, P, N) 
            # obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            # print(obj)
            P = self.update_p( h, P_max, W, U, N, sigma)
            obj = self.WMMSE_obj(h, N, P, W, U, sigma)
            # if obj1 < obj:
            #     1
            # obj1 = obj
            # print(obj)
            obj_list.append(obj)
            if (obj_list[count] - obj_list[count-1] > -10**-3)&(count>50):
                break
            count +=1
            # if count>5:
            #     break
            
        return P
    
    
    
    def update_p1(self, h, P_max, W, U, N, sigma, weights):
        P = np.zeros(N)
        for k in range(N):
            P[k] = h[k, k]*U[k]*W[k]*weights[k]/((h[:, k]**2*U**2*W*weights).sum())
            P[k] = min(P[k], P_max[k]**0.5)
        return P
        
    def update_p(self, h, P_max, W, U, N, sigma):
        P = np.zeros(N)
        for k in range(N):
            P[k] = h[k, k]*U[k]*W[k]/((h[:, k]**2*U**2*W).sum())
            P[k] = min(P[k], P_max[k]**0.5)
        return P
    def update_u(self, h, P, N, sigma):
        U = np.zeros(N)
        for k in range(N):
            U[k] = h[k,k]*P[k]/((h[k, :]**2*P**2).sum()+sigma**2)
        return U
    def update_w(self, U, h, P, N):
        W = np.zeros(N)
        for k in range(N):
            W[k] = 1/(1 - U[k]*h[k, k]*P[k])
            if np.isnan(W.sum()):
                aaa=1
        return W
    def WMMSE_obj(self, h, N, P, W, U, sigma):
        e = np.zeros([N])
        for k in range(N):
            e[k] = np.abs(U[k]*h[k,k]*P[k]-1)**2 \
                + (np.abs(U[k]*h[k, :]*P)**2).sum() \
                    - np.abs(U[k]*h[k, k]*P[k])**2 + sigma**2*np.abs(U[k])**2
        obj = (e*W).sum() - np.log(W).sum()
        return obj
    def WMMSE_obj1(self, h, N, P, W, U, sigma, weights):
        e = np.zeros([N])
        for k in range(N):
            e[k] = np.abs(U[k]*h[k,k]*P[k]-1)**2 \
                + (np.abs(U[k]*h[k, :]*P)**2).sum() \
                    - np.abs(U[k]*h[k, k]*P[k])**2 + sigma**2*np.abs(U[k])**2
        obj = (weights*e*W).sum() - (weights*np.log(W)).sum()
        return obj
    
 # -*- coding: utf-8 -*-
"""
Created on Fri Oct  1 10:45:45 2021

@author: xukai
"""


def rate_check(s_g_all, actions, M, N):
    interf = np.zeros([M])
    Rate_all = np.zeros([M])
    for n in range(N):
        for j in range(N):
            if j!=n:
                interf[n] += np.abs(s_g_all[n, j])**2*actions[j]
        Rate_all[n] = np.log(1 + ( np.abs(s_g_all[n, n])**2*actions[n] )/(interf[n] + 1 ))                
    # a = np.sum(np.log(Rate_all.sum(1)+10**-3))
    # a = np.sum(np.minimum(Rate_all, np.log(1000)))
    a = Rate_all.sum()
    return a, Rate_all

                
        
    
    
        
        
