# -*- coding: utf-8 -*-
"""
Created on Sun Oct 23 16:44:02 2022

@author: xukai
"""

"""
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from envs_hetnet_8femto import *
import matplotlib.pyplot as plt 
from scipy.optimize import linear_sum_assignment
use_gpu = 1
device = torch.device('cuda' if torch.cuda.is_available() and use_gpu else 'cpu')
# device = torch.device('cpu')
print(device)
# from sklearn import preprocessing
# torch.utils.backcompat.broadcast_warning.enabled=False

# Hyper Parameters
LR = 0.0001                    # learning rate
EPSILON = 0.9               # greedy policy
GAMMA = 0                # reward discount
GAMMA_COMM = 0.5
TARGET_REPLACE_ITER = 10   # target update frequency


# System parameters
learning_method = 'mql'
print(learning_method)
M_n = 1 # Number of users in each cell
N = 13 # Number of cells
BATCH_SIZE = 128
MEMORY_CAPACITY = 3600
M = M_n*N # Number of users
L = M_n
M_reach = 5
N_reach = 5
Max_related_in_T = M_reach
Max_related_in_R = N_reach
Rate_req = np.ones(M)*3
A_C = 11
# Sep_reward_dim = 0
Sep_reward_dim = N*L
# Reward_dimension = N + Sep_reward_dim
Reward_dimension = 1

# N_comm = N_reach + 1 + 1
# N_local_inf = M_n + 1 + N + 3*(N_reach-1)+ (N_reach-1) +1 +1
N_local_inf = M_reach*2 + 1 #+ M_reach-1
# N_local_inf = M*N+1
N_local_inf_all = N_local_inf * N
N_R_inf = 0
N_out_R = L*N_reach
# N_ext_inf = N_out_R*M_reach
N_ext_inf = M_reach*N_R_inf
N_out_T = L*M_n*A_C # Output include Q value of (index and power of user in subspectrum l at BS n)
D_Tx = 500 # Distance between Tx nodes
min_dis = 125
N_R_inf_all = N_R_inf*M

Server = [i//M_n for i in range(M)]
User = [[i*M_n+j for j in range(M_n)] for i in range(N)]
sigma = 1
# P_all_temp = np.linspace(-1.5, 3, A_C-1)
# P_all = np.concatenate((np.array([0]),10**P_all_temp))
P_all = np.linspace(0, 1000, A_C)
int_fade = 0
P_max = np.concatenate([np.array([1000]), 10**2*np.ones(4), 10**1*np.ones(8)])
R_pre = np.ones(N)

index_even = [i*2 for i in range((2*N*L)//2)]
index_odd = [i*2+1 for i in range((2*N*L-1)//2+1)]


def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      np.random.seed(seed)
      random.seed(seed)
      torch.backends.cudnn.deterministic = True


setup_seed(2)

N_actions = L*2
N_states = N_local_inf
def Qt(P, Q_P):
    temp = np.log10(P+1e-10)
    out = np.zeros_like(P)
    index = np.maximum(0, (temp+1.5+0.25+0.5)//0.5).astype(int)
    # print(index)
    # print(P)
    if max(index)>10:
        print(max(index))
    out = Q_P[index]
    return out
d = np.ones([M, N])*10
d_Tx = np.ones([M, N])*10
def generate_dist(xy_tx, xy_rx):
    d = np.ones([M, N])*10
    for i in range(N):
        for j in range(M):
            d[j, i] = np.linalg.norm(xy_rx[j, :]-xy_tx[i, :])
            d_Tx[j, i] = np.linalg.norm(xy_tx[j, :]-xy_tx[i, :])
    return d/1000

def geneerate_positions(M_n, N, D_Tx, min_dis):
    xy_tx = np.zeros([N, 2])
    xy_rx = np.zeros([N*M_n, 2])
    direction = np.array([[0.5, 0.5*(3**0.5)], [-0.5, 0.5*(3**0.5)], [-1, 0], [-0.5, -0.5*(3**0.5)], [0.5, -0.5*(3**0.5)], [1, 0]])
    count6 = 0
    for m in User[0]:
        dis_rx =  random.uniform(min_dis, D_Tx/2)
        phi_rx =  random.uniform(-np.pi, np.pi)
        xy_rx[m, 0] = dis_rx*np.cos(phi_rx)
        xy_rx[m, 1] = dis_rx*np.sin(phi_rx)
    for n in range(1, N):
        if n > (count6+1)*count6/2*6:
            count6 += 1
            xy_tx[n, :] = count6 * D_Tx * direction[0, :]
        else:
            if n <= (count6-1)*count6/2*6 + count6+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[2, :]
            elif n <= (count6-1)*count6/2*6 + count6*2+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[3, :]
            elif n <= (count6-1)*count6/2*6 + count6*3+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[4, :]
            elif n <= (count6-1)*count6/2*6 + count6*4+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[5, :]
            elif n <= (count6-1)*count6/2*6 + count6*5+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[0, :]
            elif n <= (count6-1)*count6/2*6 + count6*6+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[1, :]
        for m in User[n]:
            dis_rx =  random.uniform(min_dis, D_Tx/2)
            phi_rx =  random.uniform(-np.pi, np.pi)
            xy_rx[m, 0] = dis_rx*np.cos(phi_rx) + xy_tx[n, 0]
            xy_rx[m, 1] = dis_rx*np.sin(phi_rx) + xy_tx[n, 1]
    return xy_tx, xy_rx
        
def generate_indices(d):
    N_index = []
    M_index = []
    for n in range(N):
        M_index.append(np.argsort(d[:, n])[0:Max_related_in_T].tolist())
    for m in range(M):
        N_index.append( np.sort(np.argsort(d[m, :])[0:Max_related_in_R]).tolist())
    return M_index, N_index

def generate_neighbour(d_Tx):
    Ne_index = []
    for n in range(N):
        Ne_index.append(np.where(d_Tx[:, n]<=D_Tx+1)[0])
    return Ne_index

xy_Tx, xy_Rx = geneerate_positions(M_n, N, D_Tx, min_dis)
d_Tx[range(N), range(N)]+=1000
d = generate_dist(xy_Tx, xy_Rx)
Ne_index = generate_neighbour(d_Tx)
M_index, N_index = generate_indices(d)

        
env = Envir(M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis, P_max)
env4test = Envir(M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis, P_max)



#state s : 2D array(row vector): (channel gains, Rate_Rx, SINR, Interf)

HNIN = N_local_inf
# HNL1 = 256
HNL2 = 128
HNL3 = 64
cop_L1 = 128
cop_L2 = 128
HNOUT = A_C
class Net(nn.Module):
    def __init__(self, ):
        super(Net, self).__init__()
        self.fc2 = nn.Linear(HNIN, HNL2)
        self.fc3 = nn.Linear(HNL2, HNL3)
        self.fc4 = nn.Linear(HNL3, HNOUT)
        self.fc4_mean = nn.Linear(HNL3, 1)
        self.LKRL = nn.LeakyReLU(0.1)    
    def forward(self, s):
        # temp = self.LKRL(self.cop_fc2(self.LKRL(
        #     self.cop_fc1(s))))
        temp1 = self.LKRL(self.fc3(#temp+
                self.LKRL(self.fc2(s))))
        out = self.fc4(temp1) - torch.mean(self.fc4(temp1), 1, keepdim=True) + self.fc4_mean(temp1)
                    # self.LKRL(self.fc1(s)))))))
        return out
    



class DQN(object):
    def __init__(self):
        if device.type == 'cuda':
            self.eval_net_cent = Net().to(dtype = torch.float).cuda()   
        elif device.type == 'cpu':
            self.eval_net_cent = Net().to(dtype = torch.float)
        self.eval_net_list = []
        self.target_net_list = []
        if device.type == 'cuda':
            for n in range(N):
                self.eval_net_list.append(Net().to(dtype = torch.float).cuda())
                self.target_net_list.append(Net().to(dtype = torch.float).cuda())
        elif device.type == 'cpu':
            for n in range(N):
                self.eval_net_list.append(Net().to(dtype = torch.float))
                self.target_net_list.append(Net().to(dtype = torch.float))
        
        self.learn_step_counter = 0                                     # for target updating
        self.memory_counter = 0                                         # for storing memory
        # self.memory = np.zeros([MEMORY_CAPACITY, N_states * 2 + N_actions + Reward_dimension])     # initialize memory
        self.memory = []
        self.optimizer_list = []
        for n in range(N):
            self.memory.append([])
            self.optimizer_list.append(torch.optim.Adam(self.eval_net_list[n].parameters(), lr=LR))
        
    def store_transition(self, s, a, r, s_, g_all):
        if self.memory_counter<MEMORY_CAPACITY:
            for n in range(N):
                self.memory[n].append((s[n], a[n], r[n], s_[n], g_all[n]))            
        else:
            for n in range(N):
                self.memory[n][self.memory_counter%MEMORY_CAPACITY]=(s[n], a[n], r[n], s_[n], g_all[n])
        self.memory_counter += 1
    
    def choose_action(self, s, s_g_all, epsilon):
        s = torch.FloatTensor(s).view([ N, N_local_inf])
        actions = np.zeros([N])
        for n in range(N):
            if random.uniform(0, 1) < epsilon:
                actions[n] = self.eval_net_list[n](s[n].to(device).view([1, -1])).squeeze().argmax()
            else:
                actions[n] = np.random.randint(0, A_C)
        return actions.astype(int)
    
    def learn(self, N_nei, learning_method):
        self.learn_step_counter += 1
        b_s = torch.zeros([BATCH_SIZE, N, N_local_inf]).to(device)
        b_a = torch.zeros([BATCH_SIZE, N]).to(int).to(device)
        b_r = torch.zeros([BATCH_SIZE, N, Reward_dimension]).to(device)
        for n in range(N):
            memory_temp = (random.sample(self.memory[n], BATCH_SIZE))
            b_s[:, n, :] = torch.FloatTensor(np.array([d[0] for d in memory_temp])).view([-1, N_local_inf]).to(device)
            b_a[:, n] = torch.FloatTensor(np.array([d[1] for d in memory_temp])).view([-1]).to(device)
            b_r[:, n, :] = torch.FloatTensor(np.array([d[2] for d in memory_temp])).view([-1, Reward_dimension]).to(device)
        
        for n in range(N):
            self.optimizer_list[n].zero_grad()
            temp_q = self.eval_net_list[n](b_s[:, n, :])
            q_eval = torch.gather(temp_q,  1, b_a[:, n].view([-1,1]))
            q_target = b_r[:, n, 0:1]/(N_nei+1)
            temp_q_max = temp_q.max(1)[0].view([-1,1]).detach()
            indices = (temp_q_max<q_target*0.9).detach()
            index2 = (temp_q_max-1<temp_q).detach()
            if learning_method == 'hql':
                loss = ((1-(q_eval>q_target)*0.6)*(q_eval-q_target)**2).mean()
                loss.backward()
            elif learning_method == 'iql':
                loss = ((q_eval-q_target)**2).mean()
                loss.backward()
            elif learning_method == 'mql':
                loss = (1*(q_eval-q_target)**2).sum() + 0.05*((index2*indices*temp_q).sum()\
                                                          - ((temp_q_max-1 <q_eval)*indices*q_eval).sum()\
                                                          # - (indices*(temp_q.argmax(1)!=b_a[:, n]).view([-1,1])*torch.abs(temp_q.max(1)[0]).view([-1,1])).sum()
                                                          )# filter = 1+(temp_q.max(1)[0]<q_target)*0.05
                loss.backward()
            elif learning_method == 'hql+mql':
                h_index = (1-(q_eval>q_target)*0.6)
                loss = (h_index*(q_eval-q_target)**2).mean() + 0.05*((index2*indices*temp_q).sum()/BATCH_SIZE\
                                                          - ((temp_q_max <q_eval+1)*indices*q_eval).sum()/BATCH_SIZE\
                                                          # - (indices*(temp_q.argmax(1)!=b_a[:, n]).view([-1,1])*torch.abs(temp_q.max(1)[0]).view([-1,1])).sum()
                                                          )# filter = 1+(temp_q.max(1)[0]<q_target)*0.05
                loss.backward()
            self.optimizer_list[n].step()
        return 0


def performance_test(env2, agents, P_max, rate_opt_list_one = np.array([])):
    rate_rd_list=[]
    rate_opt_list=[]
    real_rate_list=[]
    rate_fp_list=[]
    # env2.reset_random_seed()
    for epi in range(200):
        env2.reset_episode(D_Tx, min_dis)
        s_Rate_Rx, s_SINR, s_Interf, s_g_all= env2.reset()
        s_=[]
        for n in range(N):
            s_.append(np.hstack(
                (np.log(s_g_all[n,n].reshape(1, -1)),                      
                  np.log(1+s_SINR[n].reshape(1,-1)),
                  np.log(1+s_SINR[env2.M_interf[n]].reshape([1,-1])),
                  np.log(1+s_Interf[n]).reshape([1,1]),
                  np.log(1+s_Interf[env2.M_interf[n]].reshape([1, -1]))
                  )))
        s_ = np.array(s_).squeeze()
        for step in range(20):
            s=s_
            actions = agents.choose_action(s, s_g_all, 1)
            real_s_Rate_Rx, s_SINR, s_Interf, s_g_all = env2.transition(actions)
            s_=[]
            for n in range(N):
                s_.append(np.hstack(
                    (np.log(s_g_all[n,n].reshape(1, -1)),                       
                      np.log(1+s_SINR[n].reshape(1,-1)),
                      np.log(1+s_SINR[env2.M_interf[n]].reshape([1,-1])),
                      np.log(1+s_Interf[n]).reshape([1,1]),
                      np.log(1+s_Interf[env2.M_interf[n]].reshape([1, -1]))
                      )))
            s_ = np.array(s_).squeeze()
            real_rate_sum = np.sum(real_s_Rate_Rx)
            real_rate_list.append(real_rate_sum)
            if not rate_opt_list_one.shape[0]:
                wmmse_power = wmmse_base.WMMSE_alg(s_g_all, P_max**0.5, P_max, N, sigma)
                rate_opt, _ = rate_check(s_g_all, wmmse_power**2, M, N)
                rate_opt_list.append(rate_opt)
            P_rd = np.random.random([N])*P_max
            rate_rd, _ = rate_check(s_g_all, P_rd, M, N)
            rate_fp, _ = rate_check(s_g_all, P_max, M, N)
            rate_rd_list.append(rate_rd)
            rate_fp_list.append(rate_fp)
    if rate_opt_list_one.shape[0]:
        rate_opt_list = rate_opt_list_one
    length = len(rate_opt_list)
    print('Ep: ', i_episode,
            '| randompower: ', round(sum(rate_rd_list)/length, 2),
            '| fullpower: ', round(sum(rate_fp_list)/length, 2),
          '| real rate:', round(sum(real_rate_list) /length, 2), 
          '| Optimal: ', round(sum(rate_opt_list) /length, 2),
          '| relation: ', round(sum(real_rate_list)/sum(rate_opt_list), 2),
          '| Epsilon: ', round(EPSILON, 2),
          '| LR: ', LR)

    return rate_rd_list, rate_opt_list, real_rate_list, rate_fp_list
        
dqn = DQN()
rate_opt_list_np = np.load('./data/opt8f.npy')

for ran_len in range(1):
    
    env.reset_episode(D_Tx, min_dis)    
        
    print('\nCollecting experience...')
    r_list = []
    rate_rd_list=[]
    rate_opt_list=[]
    real_rate_list=[]
    rate_fp_list=[]
    rate_list = []
    loss_list = []
    rate_avg_list = []
    real_rate_list = []
    real_r_avg_epi_list = []
    count1 = 0
    count_loss = 0
    P_last = np.zeros([N,L])
    LR_temp = 0.0001
    wmmse_base = WMMSE()
    epsilon = 0.7
    for i_episode in range(10001):
        env.reset_episode(D_Tx, min_dis)
    
        M_index = env.M_index
        N_index = env.N_index
        
        if dqn.memory_counter < MEMORY_CAPACITY:
            EPSILON = 0
        else:
            epsilon*=1.0005
            EPSILON = min(epsilon, 0.99)
        s_Rate_Rx, s_SINR, s_Interf, s_g_all= env.reset()
        ep_r = 0
        count = 0
        s_=[]
        for n in range(N):
            s_.append(np.hstack(
                (np.log(s_g_all[n,n].reshape(1, -1)),                      
                  np.log(1+s_SINR[n].reshape(1,-1)),
                  np.log(1+s_SINR[env.M_interf[n]].reshape([1,-1])),
                  np.log(1+s_Interf[n]).reshape([1,1]),
                  np.log(1+s_Interf[env.M_interf[n]].reshape([1, -1]))
                  )))
        s_ = np.array(s_).squeeze()
        while True:
            s=s_            
            actions = dqn.choose_action(s, s_g_all,EPSILON)
            real_s_Rate_Rx, s_SINR, s_Interf, s_g_all = env.transition(actions)
            s_=[]
            for n in range(N):
                s_.append(np.hstack(
                    (np.log(s_g_all[n,n].reshape(1, -1)),                       
                      np.log(1+s_SINR[n].reshape(1,-1)),
                      np.log(1+s_SINR[env.M_interf[n]].reshape([1,-1])),
                      np.log(1+s_Interf[n]).reshape([1,1]),
                      np.log(1+s_Interf[env.M_interf[n]].reshape([1, -1]))
                      )))
            s_ = np.array(s_).squeeze()
            rate_local = np.take(real_s_Rate_Rx.squeeze(), np.array(env.reward_nei_index))
            r_local = rate_local.sum(1)+real_s_Rate_Rx
            dqn.store_transition(s, actions.reshape(N,-1), r_local.reshape([N, 1]), s_, s_g_all)
            
            count1+=1
            
            if dqn.memory_counter > MEMORY_CAPACITY:
                temp_val = dqn.learn(env.reward_nei, learning_method)
                if temp_val > 0:
                    loss_list.append(temp_val)
                    count_loss+=1
            count+=1
            
            if count%20==0:
                break
        if (i_episode%200==0):# & (i_episode>200):
            if i_episode < 5000:
                rate_rd_list_one, rate_opt_list_one, real_rate_list_one, rate_fp_list_one = performance_test(env4test, dqn, P_max, rate_opt_list_np[i_episode//200])
            else:
                rate_rd_list_one, rate_opt_list_one, real_rate_list_one, rate_fp_list_one = performance_test(env4test, dqn, P_max)#, rate_opt_list_np[i_episode//200])
            rate_rd_list.append(rate_rd_list_one) 
            rate_opt_list.append(rate_opt_list_one)
            real_rate_list.append(real_rate_list_one) 
            rate_fp_list.append(rate_fp_list_one)
# np.save('./data/rd8f.npy', np.array(rate_rd_list))
# np.save('./data/opt8f.npy', np.array(rate_opt_list))
# np.save('./data/'+learning_method+'8f.npy', np.array(real_rate_list))
# np.save('./data/fp8f.npy', np.array(rate_fp_list))
# for i, m in enumerate(dqn.eval_net_list):
    # torch.save(m.state_dict(), f"./models/"+learning_method+"{i}8f.pth")

