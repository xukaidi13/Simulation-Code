# -*- coding: utf-8 -*-
"""
Created on Sat Aug 21 18:49:07 2021

@author: Kaidi Xu
"""

from __future__ import division
import numpy as np
import time
import random
import math
import scipy
from scipy import special







# self.d is a matrix indicating different distance between nodes
# Rho is a 2-D array, Rho_{m,l} denote that user m receives signal from BS in subchannel l
class Envir:
    def __init__(self, d, M, M_n, M_reach, N, N_reach, L, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, M_index, N_index, Server, User, Rate_req, sigma, P_all, GAMMA):
        self.M = M
        self.M_n = M_n
        self.M_reach = M_reach
        self.N = N
        self.N_reach = N_reach
        self.d = d.copy()
        self.L = L
        self.A_C = A_C
        self.N_local_inf = N_local_inf
        self.N_local_inf_all = N_local_inf_all
        self.N_R_inf = N_R_inf
        
        self.N_out_R = N_out_R
        self.N_ext_inf = N_ext_inf
        self.N_out_T = N_out_T
        self.M_index = M_index
        self.N_index = N_index
        self.Server = Server
        self.User = User
        self.Rate_req = Rate_req
        self.sigma = sigma
        self.P_all = P_all
        self.gamma = 1
        
        self.sigma = 10**(-11.4+11.4) # self.sigma is measured in dbm, so P sould be measured in dbm too
        self.channel_num = 100
        self.path_loss_con = 120.9-114 
        self.shadow = 10**(np.random.normal(0,8, [M, N, L])/20)
        self.path_loss_coe = 37.6
        # self.fd = 3000/3600/3/10**8*2.5*10**9
        self.fd = 10
        self.T = 0.02
        self.h_all = np.zeros([self.M,self.N,self.L]).astype(complex) # Small scale channel gain
         # random.seed(3)
        for m in range(self.M):
            for n in range(self.N):
                for l in range(self.L):
                    self.h_all[m,n,l] = (random.gauss(0,1) + 1j*random.gauss(0,1))*np.sqrt(2)/2
        # self.h_all = random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N, 2*self.L)).view(np.complex128)
        self.g_all = np.zeros([self.M,self.N,self.L]) # Channel gain
        self.rho = 0
        self.delta_rates = np.zeros([self.M, self.L])
        
        
        self.alpha = self.Channel_gain_between_ik(self.d)
        self.alpha*= self.shadow
        # self.User_association()
        self.Channel_eval()
        
    def reset_epi(self, D_Tx, min_dis):
        
        self.xy_Tx, self.xy_Rx = self.generate_positions(self.M_n, self.N, D_Tx, min_dis)
        self.d = self.generate_dist(self.xy_Tx, self.xy_Rx)
        self.alpha = self.Channel_gain_between_ik(self.d)
        self.shadow = 10**(np.random.normal(0,8, [self.M, self.N, self.L])/20)
        self.alpha*= self.shadow
        self.h_all = np.zeros([self.M,self.N,self.L]).astype(complex) # Small scale channel gain
         # random.seed(3)
        for m in range(self.M):
            for n in range(self.N):
                for l in range(self.L):
                    self.h_all[m,n,l] = (random.gauss(0,1) + 1j*random.gauss(0,1))*np.sqrt(2)/2
        # self.h_all = random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N, 2*self.L)).view(np.complex128)
        self.g_all = np.zeros([self.M,self.N,self.L]) # Channel gain       
        # self.User_association()
        self.Channel_eval()
        
    def reset(self):
        SINR = np.zeros([self.M, self.L])
        Interf = np.zeros([self.M, self.L])
        Rate_Rx = np.zeros([self.M,1])
        return Rate_Rx, SINR, Interf, np.abs(self.g_all)
        
    def transition(self, actions, int_fade):
        P        = np.zeros([self.N, self.L])
        Rho      = np.zeros([self.M, self.N, self.L])
        for n in range(self.N):
            for l in range(self.L):
                P[n][l] = actions[n,l,1]
                Rho[actions[n,l,0].astype(int), n, l] = 1*(actions[n,l,1]>0)
        actions = actions.astype(int)
        Rate, fake_Rate, SINR, Interf = self.cal_rates(Rho, int_fade, self.g_all, P)
        Rate_Rx = np.sum(Rate, 1)        
        self.Channel_eval()        
        Interf = np.zeros([self.M, self.L])
        for m in range(self.M):
            for l in range(self.L):
                for n in range(self.N):    
                    if (n!=self.Server[m]):
                        Interf[m,l] += (abs(self.g_all[m][n][l])**2)*P[n][l]
        return Rate_Rx, SINR, Interf+self.sigma**2 , np.abs(self.g_all)

    
                    
    def cal_rates(self, Rho, int_fade, s_g_all, P):
        SINR      = np.zeros([self.M, self.L])
        fake_SINR = np.zeros([self.M, self.L])
        Rate      = np.zeros([self.M, self.L])
        fake_Rate = np.zeros([self.M, self.L])
        Interf    = np.zeros([self.M, self.L])
        
        for m in range(self.M):
            for l in range(self.L):
                for n in range(self.N):    
                    if (n!=self.Server[m]):
                        Interf[m,l] += (abs(s_g_all[m][n][l])**2)*P[n][l]
                if Rho[m][self.Server[m]][l] == 1:
                    Rate[m,l], fake_Rate[m, l], SINR[m, l], _ =  self.rate_cal_for_one_user(m, l, int_fade, s_g_all, P)                
        return Rate, fake_Rate, SINR, Interf
    
    def rate_cal_for_one_user(self, m, l, int_fade, s_g_all, P):
        Interf = 0
        SINR = 0
        fake_SINR = 0    
        for n in range(self.N):    
            if (n!=self.Server[m]):
                Interf += (abs(s_g_all[m][n][l])**2)*P[n][l]
        SINR = P[self.Server[m]][l]*(abs(s_g_all[m][self.Server[m]][l])**2)/(Interf+self.sigma**2)
        fake_SINR = P[self.Server[m]][l]*(abs(s_g_all[m][self.Server[m]][l])**2)/(int_fade*Interf+self.sigma**2)
        Rate = np.log(1+SINR)
        fake_Rate = np.log(1+fake_SINR)
        return Rate, fake_Rate, SINR, Interf
    
    def Channel_eval(self):        
        self.rho = special.jv(0, 2*np.pi*self.fd*self.T)
        e =  np.random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N, 2*self.L)).view(np.complex128)
        for m in range(self.M):
            for n in range(self.N):
                for l in range(self.L):
                    e[m,n,l] = (random.gauss(0,1) + 1j*random.gauss(0,1))*np.sqrt(2)/2
        # e =  random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N, 2*self.L)).view(np.complex128)
        self.h_all = self.rho*self.h_all + ((1-self.rho**2)**0.5)*e
        self.g_all = self.h_all*self.alpha
                
    def Channel_gain_between_ik(self, d):
        alpha_o = np.zeros([self.M,self.N,self.L])
        for n in range(self.N):
            for m in range(self.M):
                for l in range(self.L):
                    alpha_o[m, n, l] = 10**(-1*(self.path_loss_con + self.path_loss_coe*math.log10(d[m,n]))/20)
        return alpha_o
    
    def generate_dist(self, xy_tx, xy_rx):
        d = np.ones([self.M, self.N])*10
        for i in range(self.N):
            for j in range(self.M):
                d[j, i] = np.linalg.norm(xy_rx[j, :]-xy_tx[i, :])
        return d/1000
    
    def generate_positions(self, M_n, N, D_Tx, min_dis):
        xy_tx = np.zeros([self.N, 2])
        xy_rx = np.zeros([self.N*self.M_n, 2])
        direction = np.array([[0.5, 0.5*(3**0.5)], [-0.5, 0.5*(3**0.5)], [-1, 0], [-0.5, -0.5*(3**0.5)], [0.5, -0.5*(3**0.5)], [1, 0]])
        count6 = 0
        for m in self.User[0]:
            dis_rx =  random.uniform(min_dis, D_Tx/2)
            phi_rx =  random.uniform(-np.pi, np.pi)
            xy_rx[m, 0] = dis_rx*np.cos(phi_rx)
            xy_rx[m, 1] = dis_rx*np.sin(phi_rx)
        for n in range(1, N):
            if n > (count6+1)*count6/2*6:
                count6 += 1
                xy_tx[n, :] = count6 * D_Tx * direction[0, :]
            else:
                if n <= (count6-1)*count6/2*6 + count6+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[2, :]
                elif n <= (count6-1)*count6/2*6 + count6*2+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[3, :]
                elif n <= (count6-1)*count6/2*6 + count6*3+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[4, :]
                elif n <= (count6-1)*count6/2*6 + count6*4+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[5, :]
                elif n <= (count6-1)*count6/2*6 + count6*5+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[0, :]
                elif n <= (count6-1)*count6/2*6 + count6*6+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[1, :]
            for m in self.User[n]:
                dis_rx =  random.uniform(min_dis, D_Tx/2)
                phi_rx =  random.uniform(-np.pi, np.pi)
                xy_rx[m, 0] = dis_rx*np.cos(phi_rx) + xy_tx[n, 0]
                xy_rx[m, 1] = dis_rx*np.sin(phi_rx) + xy_tx[n, 1]
        return xy_tx, xy_rx
            
                
        
    
    
        
        
