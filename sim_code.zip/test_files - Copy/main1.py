# -*- coding: utf-8 -*-
"""
Created on Sun Oct 23 16:44:02 2022

@author: xukai
"""

"""
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from envs_hetnet import *
import matplotlib.pyplot as plt
import untitled0_for_multi_agent_unfold_no_t_cor_modified_direct_link
# from Base_line import *
# import test_Fun_clear
from scipy.optimize import linear_sum_assignment
use_gpu = 1
device = torch.device('cuda' if torch.cuda.is_available() and use_gpu else 'cpu')
# device = torch.device('cpu')
print(device)
# from sklearn import preprocessing
# torch.utils.backcompat.broadcast_warning.enabled=False

# Hyper Parameters
LR = 0.0001                    # learning rate
EPSILON = 0.9               # greedy policy
GAMMA = 0                # reward discount
GAMMA_COMM = 0.5
TARGET_REPLACE_ITER = 10   # target update frequency


# System parameters

M_n = 1 # Number of users in each cell
N = 9 # Number of cells
BATCH_SIZE = 128
MEMORY_CAPACITY = 5000
M = M_n*N # Number of users
L = M_n
M_reach = min(M_n*6, M_n+6) # Number of users near each cell
M_reach = 6
N_reach = min(6, N) # Number of cells near each user
N_reach = 6
Max_related_in_T = M_reach
Max_related_in_R = N_reach
Rate_req = np.ones(M)*3
A_C = 11
# Sep_reward_dim = 0
Sep_reward_dim = N*L
# Reward_dimension = N + Sep_reward_dim
Reward_dimension = 1

# N_comm = N_reach + 1 + 1
# N_local_inf = M_n + 1 + N + 3*(N_reach-1)+ (N_reach-1) +1 +1
N_local_inf = M_reach + 1 #+ M_reach-1
# N_local_inf = M*N+1
N_local_inf_all = N_local_inf * N
N_R_inf = 0
N_out_R = L*N_reach
# N_ext_inf = N_out_R*M_reach
N_ext_inf = M_reach*N_R_inf
N_out_T = L*M_n*A_C # Output include Q value of (index and power of user in subspectrum l at BS n)
D_Tx = 500 # Distance between Tx nodes
min_dis = 125
N_R_inf_all = N_R_inf*M

Server = [i//M_n for i in range(M)]
User = [[i*M_n+j for j in range(M_n)] for i in range(N)]
sigma = 1
# P_all_temp = np.linspace(-1.5, 3, A_C-1)
# P_all = np.concatenate((np.array([0]),10**P_all_temp))
P_all = np.linspace(0, 1000, A_C)
int_fade = 0
P_max = np.concatenate([np.array([1000]), 10**2.3*np.ones(4), 100*np.ones(4)])
R_pre = np.ones(N)

index_even = [i*2 for i in range((2*N*L)//2)]
index_odd = [i*2+1 for i in range((2*N*L-1)//2+1)]


def setup_seed(seed):
      torch.manual_seed(seed)
      torch.cuda.manual_seed_all(seed)
      np.random.seed(seed)
      random.seed(seed)
      torch.backends.cudnn.deterministic = True


setup_seed(2)

N_actions = L*2
N_states = N_local_inf
def Qt(P, Q_P):
    temp = np.log10(P+1e-10)
    out = np.zeros_like(P)
    index = np.maximum(0, (temp+1.5+0.25+0.5)//0.5).astype(int)
    # print(index)
    # print(P)
    if max(index)>10:
        print(max(index))
    out = Q_P[index]
    return out
d = np.ones([M, N])*10
d_Tx = np.ones([M, N])*10
def generate_dist(xy_tx, xy_rx):
    d = np.ones([M, N])*10
    for i in range(N):
        for j in range(M):
            d[j, i] = np.linalg.norm(xy_rx[j, :]-xy_tx[i, :])
            d_Tx[j, i] = np.linalg.norm(xy_tx[j, :]-xy_tx[i, :])
    return d/1000

def geneerate_positions(M_n, N, D_Tx, min_dis):
    xy_tx = np.zeros([N, 2])
    xy_rx = np.zeros([N*M_n, 2])
    direction = np.array([[0.5, 0.5*(3**0.5)], [-0.5, 0.5*(3**0.5)], [-1, 0], [-0.5, -0.5*(3**0.5)], [0.5, -0.5*(3**0.5)], [1, 0]])
    count6 = 0
    for m in User[0]:
        dis_rx =  random.uniform(min_dis, D_Tx/2)
        phi_rx =  random.uniform(-np.pi, np.pi)
        xy_rx[m, 0] = dis_rx*np.cos(phi_rx)
        xy_rx[m, 1] = dis_rx*np.sin(phi_rx)
    for n in range(1, N):
        if n > (count6+1)*count6/2*6:
            count6 += 1
            xy_tx[n, :] = count6 * D_Tx * direction[0, :]
        else:
            if n <= (count6-1)*count6/2*6 + count6+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[2, :]
            elif n <= (count6-1)*count6/2*6 + count6*2+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[3, :]
            elif n <= (count6-1)*count6/2*6 + count6*3+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[4, :]
            elif n <= (count6-1)*count6/2*6 + count6*4+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[5, :]
            elif n <= (count6-1)*count6/2*6 + count6*5+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[0, :]
            elif n <= (count6-1)*count6/2*6 + count6*6+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[1, :]
        for m in User[n]:
            dis_rx =  random.uniform(min_dis, D_Tx/2)
            phi_rx =  random.uniform(-np.pi, np.pi)
            xy_rx[m, 0] = dis_rx*np.cos(phi_rx) + xy_tx[n, 0]
            xy_rx[m, 1] = dis_rx*np.sin(phi_rx) + xy_tx[n, 1]
    return xy_tx, xy_rx
        
def generate_indices(d):
    N_index = []
    M_index = []
    for n in range(N):
        M_index.append(np.argsort(d[:, n])[0:Max_related_in_T].tolist())
    for m in range(M):
        N_index.append( np.sort(np.argsort(d[m, :])[0:Max_related_in_R]).tolist())
    return M_index, N_index

def generate_neighbour(d_Tx):
    Ne_index = []
    for n in range(N):
        Ne_index.append(np.where(d_Tx[:, n]<=D_Tx+1)[0])
    return Ne_index

xy_Tx, xy_Rx = geneerate_positions(M_n, N, D_Tx, min_dis)
d_Tx[range(N), range(N)]+=1000
d = generate_dist(xy_Tx, xy_Rx)
Ne_index = generate_neighbour(d_Tx)
M_index, N_index = generate_indices(d)

        
env = Envir(M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis, P_max)
# env2 = untitled0_for_multi_agent_unfold_no_t_cor_modified_direct_link.Envir( d, M, M_n, M_reach, N, N_reach, L, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, M_index, N_index, Server, User, Rate_req, sigma, P_all, GAMMA)
env4test = Envir(M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis, P_max)



#state s : 2D array(row vector): (channel gains, Rate_Rx, SINR, Interf)

HNIN = N_local_inf
# HNL1 = 256
HNL2 = 128
HNL3 = 64
cop_L1 = 128
cop_L2 = 128
HNOUT = A_C
class Net(nn.Module):
    def __init__(self, ):
        super(Net, self).__init__()
        self.fc2 = nn.Linear(HNIN, HNL2)
        self.fc3 = nn.Linear(HNL2, HNL3)
        self.fc4 = nn.Linear(HNL3, HNOUT)
        self.fc4_mean = nn.Linear(HNL3, 1)
        self.LKRL = nn.LeakyReLU(0.1)    
    def forward(self, s):
        # temp = self.LKRL(self.cop_fc2(self.LKRL(
        #     self.cop_fc1(s))))
        temp1 = self.LKRL(self.fc3(#temp+
                self.LKRL(self.fc2(s))))
        out = self.fc4(temp1) - torch.mean(self.fc4(temp1), 1, keepdim=True) + self.fc4_mean(temp1)
                    # self.LKRL(self.fc1(s)))))))
        return out
    



class DQN(object):
    def __init__(self):
        if device.type == 'cuda':
            self.eval_net_cent = Net().to(dtype = torch.float).cuda()   
        elif device.type == 'cpu':
            self.eval_net_cent = Net().to(dtype = torch.float)
        self.eval_net_list = []
        self.target_net_list = []
        if device.type == 'cuda':
            for n in range(N):
                self.eval_net_list.append(Net().to(dtype = torch.float).cuda())
                self.target_net_list.append(Net().to(dtype = torch.float).cuda())
        elif device.type == 'cpu':
            for n in range(N):
                self.eval_net_list.append(Net().to(dtype = torch.float))
                self.target_net_list.append(Net().to(dtype = torch.float))
        
        # for n in range(N):
        #     eval_name = './trained_models/eval_q_'+str(n)+'.pt'
        #     targ_name = './trained_models/target_q_'+str(n)+'.pt'
        #     self.eval_net_list.append(torch.load(eval_name).cuda())
        #     self.target_net_list.append(torch.load(targ_name).cuda())
        self.learn_step_counter = 0                                     # for target updating
        self.memory_counter = 0                                         # for storing memory
        # self.memory = np.zeros([MEMORY_CAPACITY, N_states * 2 + N_actions + Reward_dimension])     # initialize memory
        self.memory = []
        self.optimizer_list = []
        self.comm_optimizer_list = []
        self.unsup_optimizer_list = []
        for n in range(N):
            self.memory.append([])
            # self.unsup_optimizer_list.append(torch.optim.Adam(self.unsup_net_list[n].parameters(), lr=LR*10))
            self.optimizer_list.append(torch.optim.Adam(self.eval_net_list[n].parameters(), lr=LR))
        # self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=LR)
        # self.schedular = torch.optim.lr_scheduler.StepLR(self.optimizer,100,gamma=0.99,last_epoch=-1,verbose=False)
        self.loss_func = nn.MSELoss()
        
    def store_transition(self, s, a, r, s_, g_all):
        # self.memory_counter += 1
        if self.memory_counter<MEMORY_CAPACITY:
            for n in range(N):
                self.memory[n].append((s[n], a[n], r[n], s_[n], g_all[n]))            
        else:
            for n in range(N):
                self.memory[n][self.memory_counter%MEMORY_CAPACITY]=(s[n], a[n], r[n], s_[n], g_all[n])
        self.memory_counter += 1
    
    def choose_action(self, s, s_g_all, epsilon):
        s = torch.FloatTensor(s).view([ N, N_local_inf])
        # comm_state_last = torch.FloatTensor(comm_actions_last).view([N, N_comm])
        actions = np.zeros([N])
        unsup_power = np.zeros([N])
        for n in range(N):
            if random.uniform(0, 1) < epsilon:
                actions[n] = self.eval_net_list[n](s[n].to(device).view([1, -1])).squeeze().argmax()
            else:
                actions[n] = np.random.randint(0, A_C)
            # print(self.unsup_net_list[n](s[n].to(device)).detach().cpu().squeeze().numpy())
            # unsup_power[n] = self.unsup_net_list[n](s[n].to(device)).detach().cpu().squeeze().numpy()
        unsup_power = np.ones([N])*(P_max[0])
        return actions.astype(int), unsup_power
    
    def learn(self, ):
        self.learn_step_counter += 1
        memory_temp = []
        b_s = torch.zeros([BATCH_SIZE, N, N_local_inf]).to(device)
        b_a = torch.zeros([BATCH_SIZE, N]).to(int).to(device)
        b_r = torch.zeros([BATCH_SIZE, N, Reward_dimension]).to(device)
        for n in range(N):
            memory_temp.append(random.sample(self.memory[n], BATCH_SIZE))
            b_s[:, n, :] = torch.FloatTensor(np.array([d[0] for d in memory_temp[n]])).view([-1, N_local_inf]).to(device)
            b_a[:, n] = torch.FloatTensor(np.array([d[1] for d in memory_temp[n]])).view([-1]).to(device)
            b_r[:, n, :] = torch.FloatTensor(np.array([d[2] for d in memory_temp[n]])).view([-1, Reward_dimension]).to(device)
        
        for n in range(N):
            self.optimizer_list[n].zero_grad()
            if random.randint(0,1)<1:
                temp_q = self.eval_net_list[n](b_s[:, n, :])
                q_eval = torch.gather(temp_q,  1, b_a[:, n].view([-1,1]))
                q_target = b_r[:, n, 0:1]/7
                # print(q_target)
                indices = (temp_q.max(1)[0].view([-1,1]).detach()<q_target*0.9)
                index2 = (temp_q.max(1)[0].view([-1,1]).detach()<temp_q*1.2)
                loss = ((q_eval-q_target)**2).sum() + 0.05*((index2*indices*temp_q).sum()\
                                                          - ((temp_q.max(1)[0].view([-1,1]).detach()<q_eval*1.2)*indices*q_eval).sum()\
                                                          # - (indices*(temp_q.argmax(1)!=b_a[:, n]).view([-1,1])*torch.abs(temp_q.max(1)[0]).view([-1,1])).sum()
                                                          )# filter = 1+(temp_q.max(1)[0]<q_target)*0.05
                loss.backward()
        # p_all=[]
        # for n in range(N):
        #     self.unsup_optimizer_list[n].zero_grad()
        #     p_all.append(self.unsup_net_list[n](b_s[:, n, :]))
        # p_all1 = torch.cat(p_all, 1)
        # loss = 0
        # for n in range(N):
        #     loss -= torch.log( 1+g_all[:, n, n]**2*p_all1[:, n]/(((g_all[:, n, :]**2*p_all1)).sum(1)-(g_all[:, n, n]**2*p_all1[:, n])+sigma**2) ).sum()
        # loss.backward()
        # temp_val = loss.item()
        # nn.utils.clip_grad_norm_(self.eval_net.parameters(), 1, norm_type=2)
        for n in range(N):
            self.optimizer_list[n].step()
            # self.comm_optimizer_list[n].step()
            # self.unsup_optimizer_list[n].step()
        # self.schedular.step()
        return loss.detach().numpy().squeeze()
    
# def performance_test(env2, agents, wmmse_alg):
    
        
        
dqn = DQN()
s_para=[]
for n in range(N):
    l = 0
    for parameters in dqn.eval_net_list[n].parameters():
        l += parameters.sum().detach().cpu().numpy()
    s_para.append(l)
ms_last = np.hstack([env.alpha.reshape(-1), EPSILON, s_para]).reshape([1, -1])
# a_learn_rate = monitor_agent.choose_action(ms_last)
a_learn_rate = 0
reward_ma = 0
comm_epsilon = 0.95

for ran_len in range(1):
    
    env.reset_episode(D_Tx, min_dis)    
    # env2.reset_epi( D_Tx, min_dis)
        
    print('\nCollecting experience...')
    rate_rd_list=[]
    rate_fp_list=[]
    rate_opt2_list=[]
    r_list = []
    unsup_list = []
    rate_base_list = []
    rate_opt_list = []
    r_avg_epi_list = []
    rate_list = []
    reward_list = []
    r_avg_list = []
    loss_list = []
    rate_avg_list = []
    real_rate_list = []
    real_r_avg_epi_list = []
    count1 = 0
    count_loss = 0
    P_last = np.zeros([N,L])
    LR_temp = 0.0001
    wmmse_base = WMMSE()
    EPSILON = 0.7
    for i_episode in range(10000):
        env.reset_episode(D_Tx, min_dis)
        # env2.reset_epi( D_Tx, min_dis)
    
        M_index = env.M_index
        N_index = env.N_index
        # M_index, N_index, _, _ = env.generate_indices(1/env.alpha)
        # M_interf = []
        # countabn = 0
        # for n in range(N):            
        #     if (n in M_index[n]):
        #         M_interf.append([])
        #         for m in M_index[n]:
        #             if not (m in User[n]):
        #                 M_interf[n].append(m)                        
        #     else:
        #         countabn+=1
        #         M_interf.append(M_index[n][0:M_reach-1])
        #         M_index[n][M_reach-1] = n
        # if countabn>0:
        #     print(countabn)
        
        s_Rate_Rx, s_SINR, s_Interf, s_g_all= env.reset()
        ep_r = 0
        count = 0
        wmmse_power = np.zeros(N)
        
        
        
        s_=[]
        for n in range(N):
            s_.append(np.hstack(
                (np.log(s_g_all[n,n].reshape(1, -1)),                      
                  np.log(1+s_SINR[n].reshape(1,-1)),
                  np.log(1+s_SINR[env.M_interf[n]].reshape([1,-1])),
                  # env.d[env.M_interf[n], n].reshape([1, -1]),
                  )))
        s_ = np.array(s_).squeeze()
        while True:
            EPSILON = min(((count1//200)/1500)+0.75, 0.99)
            if dqn.memory_counter < MEMORY_CAPACITY:
                EPSILON = 0
            s=s_            
            actions, unsup_p_all = dqn.choose_action(s, s_g_all,EPSILON)
            P_bs = np.take_along_axis(P_all.reshape([1, A_C]).repeat(N, axis = 0), actions.reshape([N, 1]), axis = 1).squeeze()
            
            rate_check1, _ = rate_check(s_g_all, P_bs, M, N)
            wmmse_power = wmmse_base.WMMSE_alg(s_g_all, P_max**0.5, P_max, N, sigma)
            # wmmse_power2 = wmmse_base.WMMSE_alg(np.abs(env2.g_all[:, :, 0]), P_max[0]**0.5*np.ones(N), P_max[0], N, sigma)
            rate_opt, _ = rate_check(s_g_all, wmmse_power**2, M, N)
            # rate_opt2, _ = rate_check(np.abs(env2.g_all[:, :, 0]), wmmse_power2**2, M, N)
            P_rd = np.random.random([N])*P_max[0]
            rate_unsup, _ = rate_check(s_g_all, P_rd, M, N)
            Q_rd_p = np.around(P_rd/100).astype(int)*100
            rate_q, _ = rate_check(s_g_all, P_max, M, N)
            rate_rd, _ = rate_check(s_g_all, Q_rd_p, M, N)
            # rate_fp, _ = rate_check(np.abs(env2.g_all[:, :, 0]), P_max, M, N)
            # rate_fp_list.append(rate_fp)
            rate_rd_list.append(rate_rd)
            # rate_opt2_list.append(rate_opt2)
            rate_opt_list.append(rate_opt)
            unsup_list.append(rate_unsup)
            rate_base_list.append(rate_q)
            
            
            actions2 = np.ones([N, 1, 2]).astype(int)
            actions2[:, 0, 0] = np.arange(N)
            actions2[:, 0, 1]*=A_C
            # env2.transition(actions2, 1)
            rate_check_act, _ = rate_check(s_g_all, actions*1000.0, M, N)
            real_s_Rate_Rx, s_SINR, s_Interf, s_g_all = env.transition(actions)
            s_=[]
            for n in range(N):
                s_.append(np.hstack(
                    (np.log(s_g_all[n,n].reshape(1, -1)),                       
                      np.log(1+s_SINR[n].reshape(1,-1)),
                      np.log(1+s_SINR[env.M_interf[n]].reshape([1,-1])),
                      # env.d[env.M_interf[n], n].reshape([1, -1]),
                      )))
            s_ = np.array(s_).squeeze()
            rate_local = np.take(real_s_Rate_Rx.squeeze(), np.array(env.reward_nei_index))
            r_local = rate_local.sum(1)
            
            
            
            
            # r = s_Rate_all
            r = rate_check_act        
            
            
            real_rate_sum = np.sum(real_s_Rate_Rx)
    
            dqn.store_transition(s, actions.reshape(N,-1), r_local.reshape([N, 1]), s_, s_g_all)
    
            real_rate_list.append(real_rate_sum)
            r_list.append(r)
            # reward_list.append(reward.sum())
            count1+=1
            
            thr = 1000
            if ((count1%thr)==0)&(count1>thr):
                print('Ep: ', i_episode,
                        '| randompower: ', round(sum(unsup_list[count1-thr:count1])/thr, 2),
                      '| reward_sum:', sum(r_list[count1 - thr:count1]) /thr,
                      '| real rate:', round(sum(real_rate_list[count1 - thr:count1]) /thr, 2), 
                      '| fullpower:', round(sum(rate_base_list[count1 - thr:count1]) /thr, 2),
                      '| Optimal:', round(sum(rate_opt_list[count1 - thr:count1]) /thr, 2),
                      '| relation:', round(sum(real_rate_list[count1 - thr:count1])/sum(rate_opt_list[count1 - thr:count1]), 2),
                      '| loss:', sum(loss_list[count_loss - thr:count_loss])/thr,
                      '| Epsilon:', round(EPSILON, 2),
                       # '| opt2:',round(sum(rate_opt2_list[count1 - thr:count1]) /thr, 2),
                       # '| fullpower2:',round(sum(rate_fp_list[count1 - thr:count1]) /thr, 2),
                       '| randompower2:',round(sum(rate_rd_list[count1 - thr:count1]) /thr, 2),
                      '| LR:', LR)
                # r_avg_list.append(sum(r_list[count1-100:count1])/100)
            if dqn.memory_counter > MEMORY_CAPACITY:
                temp_val = dqn.learn()
                if temp_val > 0:
                    loss_list.append(temp_val)
                    count_loss+=1
            count+=1
            
            if count%20==0:
                break
            # s = s_
            # if i_episode>10:
            #     exit()
        reward_ma = sum(r_list[count1 - 10:count1]) /10
np.save('idqn_loss.npy',np.array(r_list))
np.save('idqn_loss_ref.npy',np.array(rate_opt_list))
