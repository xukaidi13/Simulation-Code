# -*- coding: utf-8 -*-
"""
Created on Sat Aug 21 18:49:07 2021

@author: Kaidi Xu
"""

from __future__ import division
import numpy as np
import random
from scipy import special

# self.d is a matrix indicating different distance between nodes
# Rho is a 2-D array, Rho_{m,l} denote that user m receives signal from BS in subchannel l
class Envir:
    def __init__(self, M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, Rate_req, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis):
        self.M = M
        self.M_n = M_n
        self.M_reach = M_reach
        self.N = N
        self.N_reach = N_reach
        self.A_C = A_C
        self.N_local_inf = N_local_inf
        self.N_local_inf_all = N_local_inf_all
        self.N_R_inf = N_R_inf
        self.N_out_R = N_out_R
        self.N_ext_inf = N_ext_inf
        self.N_out_T = N_out_T        
        
        self.Max_related_in_T = Max_related_in_T
        self.Max_related_in_R = Max_related_in_R
        xy_Tx, xy_Rx = self.generate_positions(self.M_n, self.N, D_Tx, min_dis, User)
        self.d, _ = self.generate_dist(xy_Tx, xy_Rx)
        self.M_index, self.N_index = self.generate_indices(self.d)
        self.Server = Server
        self.User = User
        self.sigma = sigma
        self.P_all = P_all
        self.last_actions = np.zeros([self.N]).astype(int)
        self.gamma = 1
        
        self.sigma = 10**(-11.4+11.4) # self.sigma is measured in dbm, so P sould be measured in dbm too
        self.channel_num = 100
        self.path_loss_con = 120.9-114 
        self.shadow = 10**(np.random.normal(0,8, [M, N])/20)
        self.path_loss_coe = 37.6
        self.fd = 10
        self.T = 0.01
        self.h_all = np.zeros([self.M,self.N]).astype(complex) # Small scale channel gain
         # random.seed(3)
        self.h_all = np.random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N*2)).view(np.complex128)
        self.g_all = np.zeros([self.M,self.N]) # Channel gain
        self.rho = 0
        
        
        self.alpha = self.Channel_gain_between_ik(self.d)
        self.alpha*= self.shadow
        # self.User_association()
        self.Channel_eval()
        self.last_g_all = self.g_all.copy()
        
    def reset(self):
        SINR = np.zeros([self.M])
        Interf = np.zeros([self.M])
        Rate_Rx = np.zeros([self.M,1])
        return Rate_Rx, SINR, Interf, np.abs(self.g_all)
    
    def reset_episode(self, D_Tx, min_dis):
        xy_Tx, xy_Rx = self.generate_positions(self.M_n, self.N, D_Tx, min_dis, self.User)
        self.d, _ = self.generate_dist(xy_Tx, xy_Rx)
        self.M_index, self.N_index = self.generate_indices(self.d)
        self.h_all = np.zeros([self.M,self.N]).astype(complex) # Small scale channel gain
         # random.seed(3)
        self.h_all = np.random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N*2)).view(np.complex128)
        self.g_all = np.zeros([self.M,self.N]) # Channel gain        
        self.alpha = self.Channel_gain_between_ik(self.d)
        self.alpha*= self.shadow
        # self.User_association()
        self.Channel_eval()
        self.last_g_all = self.g_all.copy()
    
    def generate_positions(self, M_n, N, D_Tx, min_dis, user_set):
        xy_tx = np.zeros([N, 2])
        xy_rx = np.zeros([N*M_n, 2])
        direction = np.array([[0.5, 0.5*(3**0.5)], [-0.5, 0.5*(3**0.5)], [-1, 0], [-0.5, -0.5*(3**0.5)], [0.5, -0.5*(3**0.5)], [1, 0]])
        count6 = 0
        for m in user_set[0]:
            dis_rx =  random.uniform(min_dis, D_Tx/2)
            phi_rx =  random.uniform(-np.pi, np.pi)
            xy_rx[m, 0] = dis_rx*np.cos(phi_rx)
            xy_rx[m, 1] = dis_rx*np.sin(phi_rx)
        for n in range(1, N):
            if n > (count6+1)*count6/2*6:
                count6 += 1
                xy_tx[n, :] = count6 * D_Tx * direction[0, :]
            else:
                if n <= (count6-1)*count6/2*6 + count6+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[2, :]
                elif n <= (count6-1)*count6/2*6 + count6*2+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[3, :]
                elif n <= (count6-1)*count6/2*6 + count6*3+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[4, :]
                elif n <= (count6-1)*count6/2*6 + count6*4+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[5, :]
                elif n <= (count6-1)*count6/2*6 + count6*5+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[0, :]
                elif n <= (count6-1)*count6/2*6 + count6*6+1:
                    xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[1, :]
            for m in user_set[n]:
                dis_rx =  random.uniform(min_dis, D_Tx/2)
                phi_rx =  random.uniform(-np.pi, np.pi)
                xy_rx[m, 0] = dis_rx*np.cos(phi_rx) + xy_tx[n, 0]
                xy_rx[m, 1] = dis_rx*np.sin(phi_rx) + xy_tx[n, 1]
        return xy_tx, xy_rx
    
    def generate_dist(self, xy_tx, xy_rx):
        d = np.zeros([self.M, self.N])
        d_tx = np.zeros([self.N, self.N])
        for i in range(self.N):
            for j in range(self.M):
                d[j, i] = np.linalg.norm(xy_rx[j, :]-xy_tx[i, :])
                d_tx[j, i] = np.linalg.norm(xy_tx[j, :]-xy_tx[i, :])
        return d/1000, d_tx
    
    def generate_indices(self, d):
        N_index = []
        M_index = []
        for n in range(self.N):
            M_index.append( np.argsort(d[:, n])[0:self.Max_related_in_T].tolist())
        for m in range(self.M):
            N_index.append( np.argsort(d[m, :])[0:self.Max_related_in_R].tolist())
        return M_index, N_index
    
    def transition(self, actions):
        power_all = np.take_along_axis(self.P_all.reshape([1, self.A_C]).repeat(self.N, axis = 0), actions.reshape([self.N, 1]), axis = 1)
        sinr_all, interf_all = self.get_sinr(power_all.squeeze())
        rate_all = np.log(1 + sinr_all)
        return rate_all, sinr_all, interf_all , np.abs(self.g_all)

    def get_sinr(self, power):
        interf = np.zeros(self.M)
        all_power = np.array((np.abs(self.g_all)**2).dot(np.mat(power.reshape([self.N, 1])))).squeeze()
        desired_sig = np.diag(np.abs(self.g_all)**2)*power
        interf = all_power - desired_sig
        sinr_all = desired_sig/(interf + self.sigma**2)
        return sinr_all, interf   
    
    def Channel_eval(self):        
        self.rho = special.jv(0, 2*np.pi*self.fd*self.T)
        e =  np.random.normal(loc=0, scale=np.sqrt(2)/2, size=(self.M, self.N*2)).view(np.complex128)
        self.h_all = self.rho*self.h_all + ((1-self.rho**2)**0.5)*e
        self.g_all = self.h_all*self.alpha
                
    def Channel_gain_between_ik(self, d):
        alpha_o = np.zeros([self.M,self.N])
        alpha_o = 10**(-1*(self.path_loss_con + self.path_loss_coe*np.log10(self.d))/20)
        # for n in range(self.N):
        #     for m in range(self.M):
        #         alpha_o[m][n] = 10**(-1*(self.path_loss_con + self.path_loss_coe*np.log10(self.d[m][n]))/20)
        return alpha_o
    
    
            
            
                
        
    
    
        
        
