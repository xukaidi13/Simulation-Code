 # -*- coding: utf-8 -*-
"""
Created on Fri Oct  1 10:45:45 2021

@author: xukai
"""
import numpy as np

def rate_check(s_g_all, actions, M, L, N):
    interf = np.zeros([M, L])
    Rate_all = np.zeros([M, L])
    for l in range(L):
        for n in range(N):
            for j in range(N):
                if j!=n:
                    interf[actions[n,l,0].astype(int), l] += np.abs(s_g_all[actions[n,l,0].astype(int), j, l])**2*actions[j,l,1]
            Rate_all[actions[n,l,0].astype(int), l] = np.log(1 + ( np.abs(s_g_all[actions[n,l,0].astype(int), n, l])**2*actions[n,l,1] )/(interf[actions[n,l,0].astype(int), l] + 1 ))                
    # a = np.sum(np.log(Rate_all.sum(1)+10**-3))
    # a = np.sum(np.minimum(Rate_all, np.log(1000)))
    a = Rate_all.sum()
    return a#, Rate_all