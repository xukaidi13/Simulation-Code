"""
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from untitled0_for_multi_agent_unfold_no_t_cor_modified_direct_link  import *
from scipy import linalg
from torch.autograd import Variable
import matplotlib.pyplot as plt
from Base_line import *
from scipy.optimize import linear_sum_assignment
import test_Fun
# import test_Fun1
import test_Fun_clear
# import Optimal_solution
import copy
import time
import envs

# Hyper Parameters
BATCH_SIZE = 128
LR = 0.001                    # learning rate
EPSILON = 0.9               # greedy policy
GAMMA = 0.2                 # reward discount
TARGET_REPLACE_ITER = 100   # target update frequency
MEMORY_CAPACITY = 1500
POLICY_REPLACE_ITER = 700

# System parameters

M_n = 1 # Number of users in each cell
N = 20 # Number of cells
M = M_n*N # Number of users
L = M_n
M_reach = min(M_n*6, M_n*7) # Number of users near each cell
M_reach = 7
N_reach = min(6, N) # Number of cells near each user
Max_related_in_T = M_reach
Max_related_in_R = N_reach
N_neighbour = N_reach

A_C = 11
# Sep_reward_dim = 0
Sep_reward_dim = N*L
Reward_dimension = N + Sep_reward_dim


N_local_inf = M_n*L+M*N+M_n*L+(M_reach-M_n)*L*2+1#include (g_m,n,l, sinr_m,l,n, interf_l, R_m )
# N_local_inf = M*L*N
N_local_inf_all = N_local_inf * N
N_R_inf = 0
N_out_R = L*N_reach
# N_ext_inf = N_out_R*M_reach
N_ext_inf = M_reach*N_R_inf
N_out_T = L*M_n*A_C # Output include Q value of (index and power of user in subspectrum l at BS n)
D_Tx = 500 # Distance between Tx nodes
min_dis = 10
N_R_inf_all = N_R_inf*M

Server = [i//M_n for i in range(M)]
User = [[i*M_n+j for j in range(M_n)] for i in range(N)]
Rate_req = np.ones(M)*3
sigma = 1
P_all = np.array([0, 10**0, 10**1, 10**1.5, 10**2, 10**2.5, 1000])
P_all_temp = np.linspace(-1.5, 3, A_C-1)
P_all = np.concatenate((np.array([0]),10**P_all_temp))
int_fade = 0
P_max = np.ones(N)*1000
R_pre = np.ones(N)


P_not_choose = 0

threshold = 1

# RL1 = 50
# RL2 = 50
 # random.seed(5465)
 
index_even = [i*2 for i in range((2*N*L)//2)]
index_odd = [i*2+1 for i in range((2*N*L-1)//2+1)]


N_actions = N*L*2
N_states = N_local_inf*N + N_R_inf*M

d = np.ones([M, N])*10
d_Tx = np.ones([M, N])*10
def generate_dist(xy_tx, xy_rx):
    d = np.ones([M, N])*10
    for i in range(N):
        for j in range(M):
            d[j, i] = np.linalg.norm(xy_rx[j, :]-xy_tx[i, :])
            d_Tx[j, i] = np.linalg.norm(xy_tx[j, :]-xy_tx[i, :])
    return d/1000

def geneerate_positions(M_n, N, D_Tx, min_dis):
    xy_tx = np.zeros([N, 2])
    xy_rx = np.zeros([N*M_n, 2])
    direction = np.array([[0.5, 0.5*(3**0.5)], [-0.5, 0.5*(3**0.5)], [-1, 0], [-0.5, -0.5*(3**0.5)], [0.5, -0.5*(3**0.5)], [1, 0]])
    count6 = 0
    for m in User[0]:
        dis_rx =  random.uniform(min_dis, D_Tx/2)
        phi_rx =  random.uniform(-np.pi, np.pi)
        xy_rx[m, 0] = dis_rx*np.cos(phi_rx)
        xy_rx[m, 1] = dis_rx*np.sin(phi_rx)
    for n in range(1, N):
        if n > (count6+1)*count6/2*6:
            count6 += 1
            xy_tx[n, :] = count6 * D_Tx * direction[0, :]
        else:
            if n <= (count6-1)*count6/2*6 + count6+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[2, :]
            elif n <= (count6-1)*count6/2*6 + count6*2+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[3, :]
            elif n <= (count6-1)*count6/2*6 + count6*3+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[4, :]
            elif n <= (count6-1)*count6/2*6 + count6*4+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[5, :]
            elif n <= (count6-1)*count6/2*6 + count6*5+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[0, :]
            elif n <= (count6-1)*count6/2*6 + count6*6+1:
                xy_tx[n, :] = xy_tx[n-1, :] + D_Tx * direction[1, :]
        for m in User[n]:
            dis_rx =  random.uniform(min_dis, D_Tx/2)
            phi_rx =  random.uniform(-np.pi, np.pi)
            xy_rx[m, 0] = dis_rx*np.cos(phi_rx) + xy_tx[n, 0]
            xy_rx[m, 1] = dis_rx*np.sin(phi_rx) + xy_tx[n, 1]
    return xy_tx, xy_rx
        
def generate_indices(d):
    N_index = []
    M_index = []
    for n in range(N):
        M_index.append(np.argsort(d[:, n])[0:Max_related_in_T].tolist())
    for m in range(M):
        N_index.append( np.sort(np.argsort(d[m, :])[0:Max_related_in_R]).tolist())
    return M_index, N_index

def generate_neighbour(d_Tx):
    Ne_index = []
    for n in range(N):
        Ne_index.append(np.where(d_Tx[:, n]<=D_Tx+1)[0])
    return Ne_index

xy_Tx, xy_Rx = geneerate_positions(M_n, N, D_Tx, min_dis)
d_Tx[range(N), range(N)]+=1000
d = generate_dist(xy_Tx, xy_Rx)
Ne_index = generate_neighbour(d_Tx)
M_index, N_index = generate_indices(d)

    
# w_predictor_one_node = torch.load('./trained_models/predict_w_delayed_Mn7_unsup.pt')




# np.random.seed(3233)





# def wmmse_random_init(h, P_max, N, sigma, M, L ):
#     actions_wmmse_random_init = np.zeros([N, L, 2])
#     actions_wmmse_random_init[:, 0, 0] = np.array(range(N))
#     objs = np.zeros(30)
#     for sample_number in range(30):
#         p_init = np.array([random.uniform(0,1) for i in range(N)])*P_max[0]**0.5
#         if sample_number == 0:
#             p_init = P_max**0.5
#         p = wmmse_base.WMMSE_alg(h[:, :, 0], p_init, P_max[0], N, sigma)
#         actions_wmmse_random_init[:, 0, 1] = p**2
#         objs[sample_number] = test_Fun.rate_check(h, actions_wmmse_random_init, M, L, N)
#     return objs.max()

env = Envir( d, M, M_n, M_reach, N, N_reach, L, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, M_index, N_index, Server, User, Rate_req, sigma, P_all, GAMMA)
env2 = envs.Envir(M, M_n, M_reach, N, N_reach, A_C, N_local_inf, N_local_inf_all, N_R_inf, N_out_R, N_ext_inf, N_out_T, Server, User, sigma, P_all, GAMMA, Max_related_in_T, Max_related_in_R, D_Tx, min_dis)


wmmse_checker = envs.WMMSE()
rate_prop_list=[]
rate_wmmse_all_list=[]
rate_wmmse_bias_all_list=[]
rate_rd_all_list=[]
rate_full_power_all_list=[]
rate_base_all_list=[]

#%%
for N in np.arange(20,21,4):
    # dqn = DQN()
    P_max = np.ones(N)*1000
    M = M_n*N # Number of users
    L = M_n # Number of cells near each user
    Max_related_in_T = M_reach
    Max_related_in_R = N_reach
    decay_list = np.ones([M])
    A_C = 11
    # Sep_reward_dim = 0
    Sep_reward_dim = N*L
    Reward_dimension = N + Sep_reward_dim
    R_pre = np.ones(N)
    
    N_local_inf = M_n*L+M*N+M_n*L+(M_reach-M_n)*L*2+1#include (g_m,n,l, sinr_m,l,n, interf_l, R_m )
    # N_local_inf = M*L*N
    N_local_inf_all = N_local_inf * N
    N_R_inf = 0
    N_out_R = L*N_reach
    # N_ext_inf = N_out_R*M_reach
    N_ext_inf = M_reach*N_R_inf
    N_out_T = L*M_n*A_C # Output include Q value of (index and power of user in subspectrum l at BS n)
    # D_Tx = 500 # Distance between Tx nodes
    # min_dis = 200
    N_R_inf_all = N_R_inf*M
    
    Server = [i//M_n for i in range(M)]
    User = [[i*M_n+j for j in range(M_n)] for i in range(N)]
     
    index_even = [i*2 for i in range((2*N*L)//2)]
    index_odd = [i*2+1 for i in range((2*N*L-1)//2+1)]
    
    
    N_actions = N*L*2
    N_states = N_local_inf*N + N_R_inf*M
    
    
    print('\nCollecting experience...')
    Local_inf = np.zeros([1, N_local_inf*N])
    R_inf = np.zeros([1, N_R_inf*M])
    actions = np.zeros([M, L, 2])
    N_local_inf_each_l = M_n + M_n + 1
    Local_inf_ = np.zeros([1, N_local_inf*N])
    R_inf_ = np.zeros([1, N_R_inf*M])
    q_eval = torch.zeros([BATCH_SIZE, N*L*2])
    q_target = torch.zeros([BATCH_SIZE, N*L*2])
    r_list = []
    rate_base_list = []
    rate_opt_list = []
    rate_opt_bias_list = []
    r_avg_epi_list = []
    rate_list = []
    r_avg_list = []
    loss_list = []
    rate_avg_list = []
    real_rate_list = []
    real_r_avg_epi_list = []
    r_fullpower_list=[]
    r_random_list=[]
    r_opt2_list=[]
    count1 = 0
    count_loss = 0
    int_fade = 0
    P_last = np.zeros([N,L])
    LR_temp = 0.0001
    max_difference = -2
    max_base_difference = -2
    rate_rd_list = []
    rate_fullpower_list = []
    rate_fp_list = []
    rate_wmmse_random_init_list = []
    actions_fp = np.zeros([N, L, 2])
    actions_wmmse = np.zeros([N, L, 2])
    actions_wmmse_bias = np.zeros([N, L, 2])
    actions_rd = np.zeros([N, L, 2])
    actions_fullpower = np.zeros([N, L, 2])
    

    for i_episode in range(700):
        # int_fade = min([i_episode*0.2, 1])
        
        env2.reset_episode(D_Tx, min_dis)
        env.reset_epi(D_Tx, min_dis)
        M_index, N_index = generate_indices(env.d)
        M_index, N_index = generate_indices(1/env.alpha[:, :, 0])
        M_interf = []
        countabn = 0
        for n in range(N):            
            if (n in M_index[n]):
                decay_list[n]=np.where(np.array(M_index[n])==n)[0][0]
                M_interf.append([])
                for m in M_index[n]:
                    if not (m in User[n]):
                        M_interf[n].append(m)                        
            else:
                decay_list[n]=M_reach
                countabn+=1
                M_interf.append(M_index[n][0:M_reach-1])
                M_index[n][M_reach-1] = n
        if countabn>0:
            print(countabn)
        N_interf = []
        for m in range(M):
            N_interf.append([])
            for n in N_index[n]:
                if not (m in User[n]):
                    N_interf[m].append(n)
        
        fp = FP(M_n, L, N, M, User)
        wmmse_base = WMMSE()
        # int_fade = i_episode//1000/7
        alphas = env.alpha
        int_fade = 1
        s_Rate_Rx, s_SINR, s_Interf, s_g_all= env.reset()
        s_g_all = np.abs(env.h_all)
        ep_r = 0
        count = 0
        p_all = torch.ones([N])*P_max[0]**0.5
        for n in range(N):
            actions[n,0,1] = p_all[n]**2
            actions[n,0,0] = n
        real_s_Rate_Rx, s_SINR, s_Interf, s_g_all = env.transition(actions, int_fade)
        EPSILON = 1
        
        while True:
            if (count1 % 30000)==30000-1:
                LR = max([LR*0.1, 10**-6])
            for n in range(N):
                for l in range(L):
                    P_last[n,l] = actions[n,l,1]
            
            
            # YYY, rate_base_line = RNC_alg(R_pre, np.abs(env.g_all), P_max,  M, N, L, Server, User, sigma, int_fade )       
            
            # Optimal sol
            h_bias = np.zeros([N, N])
            h_bias = alphas.copy()
            h_bias[range(N), range(N)] = s_g_all[range(N), range(N)]
            wmmse_power_bias = np.zeros(N)
            actions_rd[:, 0, 0] = np.arange(N)
            actions_rd[:, 0, 1] = P_max[0]*np.random.random(N)
            actions_fullpower[:, 0, 0] = np.arange(N)
            actions_fullpower[:, 0, 1] = P_max
                
            rate_rd = test_Fun.rate_check(s_g_all, actions_rd, M, L, N)
            rate_rd2 = test_Fun.rate_check(env2.g_all.reshape([N, N, 1]), actions_rd, M, L, N)
            rate_fullpower = test_Fun.rate_check(s_g_all, actions_fullpower, M, L, N)
            rate_fullpower2 = test_Fun.rate_check(env2.g_all.reshape([N, N, 1]), actions_fullpower, M, L, N)
            # rate_fp = test_Fun.rate_check(s_g_all, actions_fp, M, L, N)
            # rate_wmmse_random_init = wmmse_random_init(s_g_all, P_max, N, sigma, M, L)
            wmmse_power = np.zeros(N)
            # wmmse_power = wmmse_base.WMMSE_alg(s_g_all[:, :, 0], P_max**0.5, P_max[0], N, sigma, test_point=real_s_Rate_Rx.sum())
            wmmse_power = wmmse_checker.WMMSE_alg(s_g_all[:, :, 0], P_max**0.5, P_max[0], N, sigma)
            actions_wmmse[:, 0, 0] = np.arange(N)
            actions_wmmse[:, 0, 1] = wmmse_power**2
            rate_opt, wmmse_rate_all1 = test_Fun_clear.rate_check(s_g_all, actions_wmmse[:, 0, 1], M, N)
            wmmse_power2 = wmmse_base.WMMSE_alg(np.abs(env2.g_all), P_max**0.5, P_max[0], N, sigma)
            # wmmse_power3 = wmmse_checker.WMMSE_alg(np.abs(env2.g_all), P_max**0.5, P_max[0], N, sigma)
            actions_wmmse2 = np.zeros([N, 1, 2])
            actions_wmmse2[:, 0, 0] = np.arange(N)
            actions_wmmse2[:, 0, 1] = wmmse_power2**2
            rate_opt2, _ = test_Fun_clear.rate_check(env2.g_all.reshape([N, N, 1]), wmmse_power2**2, M, N)
            real_s_Rate_Rx, s_SINR, s_Interf, s_g_all = env.transition(actions, int_fade)
            env2.transition((A_C-1)*np.ones([N]).astype(int))
            
            
            r = real_s_Rate_Rx.sum()
            
            real_rate_sum = np.sum(real_s_Rate_Rx)
            rate_fullpower_list.append(rate_fullpower)
            r_fullpower_list.append(rate_fullpower2)
            r_random_list.append(rate_rd2)
            r_opt2_list.append(rate_opt2)
            real_rate_list.append(real_rate_sum)
            # r_list.append(r.sum())
            # rate_base_list.append(rate_base_line)
            rate_rd_list.append(rate_rd)
            # rate_fp_list.append(rate_fp)            
            rate_opt_list.append(rate_opt)
            # rate_opt_bias_list.append(rate_opt_bias)
            thr = 1000
            if count>=0:
                
                
                count1+=1
            
                if ((count1%thr)==0)&(count1>thr):
                    print('Ep: ', i_episode,
                          '| reward_sum:', round(sum((r_list[count1 - thr:count1]))/thr, 2), 
                          '| Random power:', round(sum(rate_rd_list[count1 - thr:count1]) /thr, 2),
                          '| Full power:', round(sum(rate_fullpower_list[count1 - thr:count1]) /thr, 2),
                          '| Optimal:', round(sum(rate_opt_list[count1 - thr:count1]) /thr, 2),
                          '| relation:', round(sum(real_rate_list[count1 - thr:count1])/sum(rate_opt_list[count1 - thr:count1]), 2),
                          '| Fullpower2:', round(sum((r_fullpower_list[count1 - thr:count1]))/thr, 2), 
                          '| random2:', round(sum((r_random_list[count1 - thr:count1]))/thr, 2), 
                          '| opt2:', round(sum((r_opt2_list[count1 - thr:count1]))/thr, 2), 
                          '| loss:', sum(loss_list[- thr:])/thr ,
                          '| Epsilon:', round(EPSILON, 2),
                          '| LR:', LR)
            # if wmmse.memory_counter > MEMORY_CAPACITY:
            #     # wmmse.learn()
            #     1
            count+=1
            
            if count==20:
                break
            # if i_episode>10:
            #     exit()
        # if i_episode>59:
        #     break
    rate_prop_list.append(sum(r_list)/len(r_list))
    rate_wmmse_all_list.append(sum(rate_opt_list)/len(rate_opt_list))
    rate_wmmse_bias_all_list.append(sum(rate_opt_bias_list)/len(rate_opt_bias_list))
    rate_rd_all_list.append(sum(rate_rd_list)/len(rate_rd_list))
    rate_full_power_all_list.append(sum(rate_fullpower_list)/len(rate_fullpower_list))
    rate_base_all_list.append(sum(rate_base_list)/len(rate_base_list))    
            
   

